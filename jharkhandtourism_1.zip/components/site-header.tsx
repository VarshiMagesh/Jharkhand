"use client"

import Link from "next/link"
import { useState } from "react"
import { Button } from "@/components/ui/button"
import { cn } from "@/lib/utils"

const routes = [
  { href: "/", label: "Jharkhand Tourism" },
  { href: "/about", label: "About" },
  { href: "/destinations", label: "Destinations" },
  { href: "/plan-your-visit", label: "Plan Your Visit" },
  { href: "/local-marketplace", label: "Local Marketplace" },
  { href: "/guides", label: "Guides" },
  { href: "/feed", label: "Feed" },
  { href: "/profile", label: "Profile" },
  { href: "/dashboard", label: "Dashboard" },
  { href: "/settings", label: "Settings" },
  { href: "/contact", label: "Contact" },
]

export function SiteHeader() {
  const [open, setOpen] = useState(false)

  return (
    <header
      className="sticky top-0 z-50 bg-background/95 backdrop-blur-sm border-b transition-colors duration-300"
      role="banner"
    >
      <a
        href="#main"
        className="sr-only focus:not-sr-only focus:block focus:bg-accent focus:text-accent-foreground px-3 py-2"
      >
        Skip to content
      </a>

      <div className="mx-auto max-w-6xl px-4 sm:px-6">
        <div className="h-16 flex items-center justify-between">
          <Link href="/" className="flex items-center gap-3 hover:opacity-80 transition-opacity">
            <img src="/images/jharkhand-emblem.png" alt="Jharkhand Tourism emblem" className="h-8 w-8" />
            <span className="font-semibold text-primary text-lg">Jharkhand Tourism</span>
          </Link>

          {/* Desktop Nav */}
          <nav className="hidden md:flex items-center gap-6" aria-label="Primary">
            {routes.slice(1, 6).map((r) => (
              <Link
                key={r.href}
                href={r.href}
                className="text-sm text-foreground/90 hover:text-primary focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-accent rounded transition-colors"
              >
                {r.label}
              </Link>
            ))}
            <Button asChild className="bg-accent hover:bg-accent/90 text-accent-foreground transition-colors">
              <Link href="/plan-your-visit">Plan Your Visit</Link>
            </Button>
          </nav>

          {/* Mobile Toggle */}
          <div className="md:hidden">
            <Button
              variant="outline"
              aria-expanded={open}
              aria-controls="mobile-menu"
              aria-label="Toggle menu"
              onClick={() => setOpen((v) => !v)}
              className="border"
            >
              {open ? "Close" : "Menu"}
            </Button>
          </div>
        </div>
      </div>

      {/* Mobile Menu */}
      <div
        id="mobile-menu"
        className={cn("md:hidden border-t bg-background/95 backdrop-blur-sm", open ? "block" : "hidden")}
      >
        <div className="px-4 py-3 grid grid-cols-2 gap-3">
          {routes.slice(1, 6).map((r) => (
            <Link
              key={r.href}
              href={r.href}
              className="text-sm text-foreground hover:text-primary py-1 transition-colors"
              onClick={() => setOpen(false)}
            >
              {r.label}
            </Link>
          ))}
          <Button asChild className="col-span-2 bg-accent hover:bg-accent/90 text-accent-foreground">
            <Link href="/plan-your-visit">Plan Your Visit</Link>
          </Button>
        </div>
      </div>
    </header>
  )
}
