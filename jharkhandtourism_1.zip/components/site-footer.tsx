import Link from "next/link"
import { Phone, Mail, MapPin, ExternalLink } from "lucide-react"

export function SiteFooter() {
  return (
    <footer
      className="mt-auto bg-gradient-to-br from-green-900 via-green-800 to-green-900 text-white"
      role="contentinfo"
    >
      <div className="bg-gradient-to-r from-green-900/95 via-green-800/90 to-green-900/95">
        <div className="mx-auto max-w-6xl px-4 sm:px-6 py-12">
          <div className="grid gap-8 md:grid-cols-4">
            {/* Jharkhand Tourism Branding */}
            <div className="md:col-span-2">
              <div className="flex items-start gap-4 mb-4">
                <div className="h-12 w-12 bg-yellow-400 rounded-full flex items-center justify-center">
                  <span className="text-green-900 font-bold text-lg">JT</span>
                </div>
                <div>
                  <h3 className="text-xl font-bold text-yellow-400 mb-2">Jharkhand Tourism</h3>
                  <p className="text-green-100 text-sm leading-relaxed">
                    Experience the Soul of India – Discover Jharkhand's hidden treasures, from thundering waterfalls to
                    ancient tribal heritage. Your gateway to authentic wilderness adventures.
                  </p>
                </div>
              </div>

              <div className="grid sm:grid-cols-2 gap-4 mt-6">
                <div className="bg-green-800/50 rounded-lg p-4 border border-green-700">
                  <h4 className="font-semibold text-yellow-400 mb-2">Tourism Helplines</h4>
                  <div className="space-y-2 text-sm text-green-100">
                    <div className="flex items-center gap-2">
                      <Phone className="w-4 h-4 text-yellow-400" />
                      <span>1800-123-TOUR (8687)</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <Phone className="w-4 h-4 text-yellow-400" />
                      <span>Emergency: 112</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <Mail className="w-4 h-4 text-yellow-400" />
                      <span>help@jharkhandtourism.gov.in</span>
                    </div>
                  </div>
                </div>

                <div className="bg-green-800/50 rounded-lg p-4 border border-green-700">
                  <h4 className="font-semibold text-yellow-400 mb-2">24/7 Support</h4>
                  <div className="space-y-2 text-sm text-green-100">
                    <div className="flex items-center gap-2">
                      <MapPin className="w-4 h-4 text-yellow-400" />
                      <span>Tourist Information Centers</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <Phone className="w-4 h-4 text-yellow-400" />
                      <span>WhatsApp: +91-9876543210</span>
                    </div>
                    <div className="text-yellow-300 text-xs">Available in Hindi, English & Local languages</div>
                  </div>
                </div>
              </div>
            </div>

            {/* Quick Links */}
            <div>
              <h4 className="font-semibold text-yellow-400 mb-4">Quick Links</h4>
              <ul className="space-y-3 text-sm text-green-100">
                <li>
                  <Link
                    href="/destinations"
                    className="hover:text-yellow-300 transition-colors flex items-center gap-2"
                  >
                    <ExternalLink className="w-3 h-3" />
                    Explore Destinations
                  </Link>
                </li>
                <li>
                  <Link
                    href="/plan-your-visit"
                    className="hover:text-yellow-300 transition-colors flex items-center gap-2"
                  >
                    <ExternalLink className="w-3 h-3" />
                    Plan Your Visit
                  </Link>
                </li>
                <li>
                  <Link
                    href="/local-marketplace"
                    className="hover:text-yellow-300 transition-colors flex items-center gap-2"
                  >
                    <ExternalLink className="w-3 h-3" />
                    Local Marketplace
                  </Link>
                </li>
                <li>
                  <Link href="/guides" className="hover:text-yellow-300 transition-colors flex items-center gap-2">
                    <ExternalLink className="w-3 h-3" />
                    Verified Guides
                  </Link>
                </li>
                <li>
                  <Link href="/about" className="hover:text-yellow-300 transition-colors flex items-center gap-2">
                    <ExternalLink className="w-3 h-3" />
                    Travel Guidelines
                  </Link>
                </li>
                <li>
                  <Link href="/contact" className="hover:text-yellow-300 transition-colors flex items-center gap-2">
                    <ExternalLink className="w-3 h-3" />
                    Contact Support
                  </Link>
                </li>
              </ul>
            </div>

            {/* Government Links */}
            <div>
              <h4 className="font-semibold text-yellow-400 mb-4">Official Links</h4>
              <ul className="space-y-3 text-sm text-green-100">
                <li>
                  <a href="#" className="hover:text-yellow-300 transition-colors flex items-center gap-2">
                    <ExternalLink className="w-3 h-3" />
                    Govt. of Jharkhand
                  </a>
                </li>
                <li>
                  <a href="#" className="hover:text-yellow-300 transition-colors flex items-center gap-2">
                    <ExternalLink className="w-3 h-3" />
                    Ministry of Tourism
                  </a>
                </li>
                <li>
                  <a href="#" className="hover:text-yellow-300 transition-colors flex items-center gap-2">
                    <ExternalLink className="w-3 h-3" />
                    Forest Department
                  </a>
                </li>
                <li>
                  <a href="#" className="hover:text-yellow-300 transition-colors flex items-center gap-2">
                    <ExternalLink className="w-3 h-3" />
                    Wildlife Board
                  </a>
                </li>
                <li>
                  <a href="#" className="hover:text-yellow-300 transition-colors flex items-center gap-2">
                    <ExternalLink className="w-3 h-3" />
                    Incredible India
                  </a>
                </li>
              </ul>
            </div>
          </div>

          {/* Bottom Bar */}
          <div className="border-t border-green-700 mt-8 pt-6 flex flex-col sm:flex-row justify-between items-center gap-4">
            <div className="text-xs text-green-200">
              © {new Date().getFullYear()} Department of Tourism, Government of Jharkhand. All rights reserved.
            </div>
            <div className="flex gap-4 text-xs text-green-100">
              <Link href="/privacy" className="hover:text-yellow-300 transition-colors">
                Privacy Policy
              </Link>
              <Link href="/terms" className="hover:text-yellow-300 transition-colors">
                Terms of Service
              </Link>
              <Link href="/accessibility" className="hover:text-yellow-300 transition-colors">
                Accessibility
              </Link>
            </div>
          </div>
        </div>
      </div>
    </footer>
  )
}
