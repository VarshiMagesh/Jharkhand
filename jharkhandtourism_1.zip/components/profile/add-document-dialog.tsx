"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog"
import { Input } from "@/components/ui/input"

export function AddDocumentDialog() {
  const [open, setOpen] = useState(false)
  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>
        <Button variant="outline">Add document</Button>
      </DialogTrigger>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle>Traveler document</DialogTitle>
        </DialogHeader>
        <form className="grid gap-3">
          <Input placeholder="Document type (e.g., ID, Permit)" />
          <Input placeholder="Document number" />
          <Input type="date" aria-label="Expiry date" />
          <div className="flex justify-end gap-2">
            <Button variant="outline" type="button" onClick={() => setOpen(false)}>
              Cancel
            </Button>
            <Button type="submit" onClick={() => setOpen(false)}>
              Upload
            </Button>
          </div>
        </form>
      </DialogContent>
    </Dialog>
  )
}
