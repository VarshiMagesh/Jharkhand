const items = [
  { title: "Hundru Falls", desc: "Iconic waterfall near Ranchi.", img: "/images/dest-hundru.png" },
  { title: "Betla National Park", desc: "Wildlife and sal forests.", img: "/images/dest-betla.png" },
  { title: "Netarhat", desc: "‘Queen of Chotanagpur’ hill station.", img: "/images/dest-netarhat.png" },
  { title: "Dassam Falls", desc: "Scenic cascade on Kanchi river.", img: "/images/dest-dassam.png" },
]

export function DestinationsSection() {
  return (
    <section aria-labelledby="destinations-title" className="py-10 md:py-14 bg-white">
      <div className="mx-auto max-w-6xl px-4 sm:px-6">
        <h2 id="destinations-title" className="text-2xl font-semibold text-primary">
          Destinations & Attractions
        </h2>
        <div className="mt-6 grid gap-6 sm:grid-cols-2 lg:grid-cols-4">
          {items.map((it) => (
            <article key={it.title} className="rounded-md overflow-hidden ring-1 ring-foreground/10 bg-background">
              <img src={it.img || "/placeholder.svg"} alt={it.title} className="h-40 w-full object-cover" />
              <div className="p-4">
                <h3 className="font-semibold text-foreground">{it.title}</h3>
                <p className="text-sm text-foreground/90 mt-1">{it.desc}</p>
              </div>
            </article>
          ))}
        </div>
      </div>
    </section>
  )
}
