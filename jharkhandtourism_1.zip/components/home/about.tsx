export function AboutSection() {
  return (
    <section aria-labelledby="about-title" className="py-10 md:py-14">
      <div className="mx-auto max-w-6xl px-4 sm:px-6">
        <h2 id="about-title" className="text-2xl font-semibold text-primary text-balance">
          About Jharkhand Tourism
        </h2>
        <p className="mt-3 text-foreground/90 leading-relaxed max-w-3xl">
          Jharkhand offers a harmonious blend of nature, culture, and heritage. The Tourism Department promotes
          sustainable travel, supports local communities, and ensures visitors experience the state’s pristine
          landscapes, diverse wildlife, and unique traditions with safety and convenience.
        </p>
      </div>
    </section>
  )
}
