import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"

const features = [
  {
    title: "Dassam Falls",
    img: "/dassam-falls-jharkhand-waterfall.png",
  },
  {
    title: "Betla National Park",
    img: "/betla-national-park-jharkhand-wildlife.png",
  },
  {
    title: "Netarhat Hills",
    img: "/netarhat-hills-jharkhand-sunset-viewpoint.png",
  },
]

export default function FeaturedDestinations() {
  return (
    <>
      <div className="grid gap-6 md:grid-cols-3">
        {features.map((f) => (
          <Card key={f.title} className="overflow-hidden">
            <img src={f.img || "/placeholder.svg"} alt={f.title} className="h-44 w-full object-cover" />
            <CardHeader>
              <CardTitle className="text-lg">{f.title}</CardTitle>
            </CardHeader>
            <CardContent className="text-sm text-muted-foreground">
              A quick glimpse. Find details, routes, and safety tips in Destinations.
            </CardContent>
            <CardFooter>
              <Button asChild size="sm">
                <Link href="/destinations">View more</Link>
              </Button>
            </CardFooter>
          </Card>
        ))}
      </div>
    </>
  )
}
