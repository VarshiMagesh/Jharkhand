"use client"

import Link from "next/link"
import { Button } from "@/components/ui/button"

export default function HomeHero() {
  return (
    <section
      aria-labelledby="home-hero"
      className="relative isolate overflow-hidden bg-gradient-to-br from-background via-card to-secondary/10"
    >
      <div className="absolute inset-0 opacity-5">
        <div className="h-full w-full bg-[radial-gradient(circle_at_20%_20%,_rgba(255,215,0,0.3)_0%,_transparent_50%),radial-gradient(circle_at_80%_80%,_rgba(139,69,19,0.3)_0%,_transparent_50%),radial-gradient(circle_at_40%_60%,_rgba(75,83,32,0.3)_0%,_transparent_50%)]" />
      </div>

      <div className="container mx-auto px-4 py-14 md:py-20 relative z-10">
        <div className="grid gap-8 md:grid-cols-2 md:items-center">
          <div className="fade-in">
            <h1 id="home-hero" className="text-balance text-3xl font-semibold tracking-tight md:text-5xl text-primary">
              Discover Jharkhand's Hidden Treasures
            </h1>
            <p className="mt-3 text-base leading-relaxed text-muted-foreground md:text-lg">
              India's best-kept secret awaits. From thundering waterfalls to ancient temples, experience destinations
              most travelers never discover. Your gateway to authentic tribal culture and untouched wilderness.
            </p>
            <div className="mt-6 flex items-center gap-3 flex-wrap">
              <Button asChild className="bg-primary hover:bg-primary/90 text-primary-foreground">
                <Link href="/destinations">Explore Hidden Gems</Link>
              </Button>
              <Button
                asChild
                variant="outline"
                className="border-primary text-primary hover:bg-primary hover:text-primary-foreground bg-transparent"
              >
                <Link href="/plan-your-visit">Plan Your Adventure</Link>
              </Button>
            </div>
            <div className="mt-6 p-4 bg-accent/10 rounded-lg border border-accent/20">
              <p className="text-sm text-accent-foreground font-medium">
                📍 Over 200+ unexplored destinations • 🌿 15+ tribal communities • 💧 50+ pristine waterfalls
              </p>
              <p className="text-xs text-muted-foreground mt-1">Join thousands discovering what guidebooks miss</p>
            </div>
            <p className="mt-3 text-xs text-muted-foreground">
              Official tourism portal with verified information and 24/7 helpline support.
            </p>
          </div>
          <div
            className="aspect-[16/10] rounded-lg border bg-muted fade-in fade-in-delay-1 relative overflow-hidden"
            aria-hidden="true"
          >
            <div className="absolute inset-0 bg-gradient-to-t from-primary/20 to-transparent z-10" />
            <img
              src="/jharkhand-scenic-landscape-with-waterfalls--forest.jpg"
              alt="Scenic landscape of Jharkhand with forests and waterfalls"
              className="h-full w-full rounded-lg object-cover"
            />
            <div className="absolute bottom-4 left-4 z-20 bg-background/90 backdrop-blur-sm rounded-lg px-3 py-2">
              <p className="text-sm font-medium text-primary">Hundru Falls</p>
              <p className="text-xs text-muted-foreground">320ft of pure majesty</p>
            </div>
          </div>
        </div>
      </div>
    </section>
  )
}
