import Link from "next/link"

const cards = [
  { title: "Book Stays", desc: "Government-verified hotels and eco-stays.", href: "/marketplace#stays" },
  { title: "Hire Guides", desc: "Certified local guides for safe exploration.", href: "/marketplace#guides" },
  { title: "Transport", desc: "Official transport and tour packages.", href: "/marketplace#transport" },
]

export function MarketplaceSection() {
  return (
    <section aria-labelledby="marketplace-title" className="py-10 md:py-14">
      <div className="mx-auto max-w-6xl px-4 sm:px-6">
        <h2 id="marketplace-title" className="text-2xl font-semibold text-primary">
          Travel Marketplace
        </h2>
        <div className="mt-6 grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
          {cards.map((c) => (
            <Link
              key={c.title}
              href={c.href}
              className="block rounded-md ring-1 ring-foreground/10 bg-white p-5 hover:ring-primary transition"
            >
              <h3 className="font-semibold text-foreground">{c.title}</h3>
              <p className="text-sm text-foreground/90 mt-1">{c.desc}</p>
              <span className="mt-3 inline-block text-sm text-primary">Learn more →</span>
            </Link>
          ))}
        </div>
      </div>
    </section>
  )
}
