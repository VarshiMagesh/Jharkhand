import { Card, CardHeader, CardContent } from "@/components/ui/card"

const quotes = [
  {
    name: "Aditi, Kolkata",
    text: "Netarhat sunset was unforgettable. The official tips helped me plan around the weather perfectly.",
  },
  {
    name: "Rohan, Pune",
    text: "Dassam and Hundru were spectacular. Glad I checked permits and helplines in advance here.",
  },
  {
    name: "Emma, London",
    text: "Loved the crafts and Sarhul celebrations. The site guided us to authentic cultural experiences.",
  },
]

export default function Testimonials() {
  return (
    <div className="grid gap-6 md:grid-cols-3">
      {quotes.map((q) => (
        <Card key={q.name} className="h-full">
          <CardHeader className="text-base font-medium">{q.name}</CardHeader>
          <CardContent className="text-sm text-muted-foreground">{q.text}</CardContent>
        </Card>
      ))}
    </div>
  )
}
