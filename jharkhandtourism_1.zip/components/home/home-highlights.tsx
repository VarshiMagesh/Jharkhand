import Link from "next/link"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"

const items = [
  {
    title: "Majestic Waterfalls",
    desc: "Dassam, Hundru, Jonha—discover cascading wonders hidden in pristine forests.",
    href: "/destinations",
    icon: "💧",
  },
  {
    title: "Tribal Heritage",
    desc: "Experience living culture through authentic festivals, crafts, and traditions.",
    href: "/about",
    icon: "🎭",
  },
  {
    title: "Wildlife Sanctuaries",
    desc: "Spot elephants, tigers, and rare birds in their natural habitat.",
    href: "/destinations",
    icon: "🐘",
  },
  {
    title: "Adventure Trails",
    desc: "Trekking, rock climbing, and forest expeditions for thrill seekers.",
    href: "/marketplace",
    icon: "🏔️",
  },
]

export default function HomeHighlights() {
  return (
    <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
      {items.map((item, index) => (
        <Link key={item.title} href={item.href} className="group">
          <Card
            className={`h-full transition-all duration-300 group-hover:bg-accent/10 group-hover:border-accent/30 group-hover:shadow-lg card-dealer card-dealer-${index + 1} border/50`}
          >
            <CardHeader className="pb-3">
              <div className="flex items-center gap-2">
                <span className="text-2xl">{item.icon}</span>
                <CardTitle className="text-base text-primary group-hover:text-accent-foreground transition-colors">
                  {item.title}
                </CardTitle>
              </div>
            </CardHeader>
            <CardContent className="text-sm text-muted-foreground leading-relaxed">{item.desc}</CardContent>
          </Card>
        </Link>
      ))}
    </div>
  )
}
