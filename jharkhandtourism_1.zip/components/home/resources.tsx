import Link from "next/link"

const links = [
  { label: "Travel Advisories", href: "/links#advisories" },
  { label: "Permits & Entry Rules", href: "/links#permits" },
  { label: "Maps & Brochures", href: "/links#maps" },
  { label: "Responsible Tourism", href: "/links#responsible" },
]

export function ResourcesSection() {
  return (
    <section aria-labelledby="resources-title" className="py-10 md:py-14 bg-white">
      <div className="mx-auto max-w-6xl px-4 sm:px-6">
        <h2 id="resources-title" className="text-2xl font-semibold text-primary">
          Useful Links & Resources
        </h2>
        <ul className="mt-4 grid gap-3 sm:grid-cols-2 lg:grid-cols-4">
          {links.map((l) => (
            <li key={l.href}>
              <Link
                href={l.href}
                className="block rounded-md ring-1 ring-foreground/10 bg-background px-4 py-3 hover:ring-primary"
              >
                <span className="text-foreground">{l.label}</span>
              </Link>
            </li>
          ))}
        </ul>
      </div>
    </section>
  )
}
