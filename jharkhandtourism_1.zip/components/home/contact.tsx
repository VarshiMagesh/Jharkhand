export function ContactSection() {
  return (
    <section aria-labelledby="contact-title" className="py-10 md:py-14">
      <div className="mx-auto max-w-6xl px-4 sm:px-6">
        <h2 id="contact-title" className="text-2xl font-semibold text-primary">
          Contact Information
        </h2>
        <div className="mt-4 grid gap-6 sm:grid-cols-2">
          <div className="rounded-md ring-1 ring-foreground/10 bg-white p-5">
            <p className="font-semibold text-foreground">Tourism Directorate</p>
            <p className="text-sm text-foreground/90 mt-1">Ranchi, Jharkhand, India</p>
            <p className="text-sm text-foreground/90 mt-1">Email: info@jharkhandtourism.gov.in</p>
            <p className="text-sm text-foreground/90 mt-1">Phone: 0651-000000</p>
          </div>
          <div className="rounded-md ring-1 ring-foreground/10 bg-white p-5">
            <p className="font-semibold text-foreground">Visitor Support</p>
            <p className="text-sm text-foreground/90 mt-1">Mon–Sat, 9:00 AM – 6:00 PM</p>
            <p className="text-sm text-foreground/90 mt-1">Helpline: 1800-123-4567</p>
          </div>
        </div>
      </div>
    </section>
  )
}
