import { Card, CardHeader, CardTitle, CardContent } from "@/components/ui/card"

const items = [
  {
    title: "Sarhul",
    desc: "Spring festival celebrating nature and community among tribal groups.",
  },
  {
    title: "Karam",
    desc: "Harvest festival honoring the Karam tree with song and dance.",
  },
  {
    title: "Tusu Parab",
    desc: "Mid-winter folk festival with vibrant songs by the rivers.",
  },
]

export default function Festivals() {
  return (
    <div className="grid gap-6 md:grid-cols-3">
      {items.map((i) => (
        <Card key={i.title}>
          <CardHeader>
            <CardTitle className="text-base">{i.title}</CardTitle>
          </CardHeader>
          <CardContent className="text-sm text-muted-foreground">{i.desc}</CardContent>
        </Card>
      ))}
    </div>
  )
}
