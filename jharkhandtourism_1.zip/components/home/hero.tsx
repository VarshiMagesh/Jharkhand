import Link from "next/link"
import { Button } from "@/components/ui/button"

export function Hero() {
  return (
    <section className="bg-white">
      <div className="mx-auto max-w-6xl px-4 sm:px-6">
        <div className="grid gap-6 md:grid-cols-2 items-center py-10 md:py-14">
          <div>
            <h1 className="text-pretty text-3xl md:text-4xl font-semibold text-primary">Discover Jharkhand</h1>
            <p className="mt-3 text-foreground/90 leading-relaxed">
              From serene waterfalls and lush forests to rich tribal culture and heritage, plan an authentic journey
              across the heart of India’s nature.
            </p>
            <div className="mt-6 flex items-center gap-3">
              <Button asChild className="bg-accent hover:bg-accent/90 text-accent-foreground">
                <Link href="/marketplace">Plan Your Visit</Link>
              </Button>
              <Button asChild variant="outline" className="border text-primary hover:bg-primary/10 bg-transparent">
                <Link href="/destinations">Explore Destinations</Link>
              </Button>
            </div>
          </div>
          <div className="rounded-md overflow-hidden ring-1 ring-foreground/10">
            <img
              src="/images/hero-scenic.png"
              alt="Scenic waterfalls and forests of Jharkhand"
              className="w-full h-64 md:h-80 object-cover"
            />
          </div>
        </div>
      </div>
    </section>
  )
}
