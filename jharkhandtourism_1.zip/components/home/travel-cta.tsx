import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"

export default function TravelCTA() {
  return (
    <Card>
      <CardHeader>
        <CardTitle className="text-lg">Plan with official resources</CardTitle>
      </CardHeader>
      <CardContent className="text-sm text-muted-foreground">
        Get permits, check advisories, and find verified services for a smooth trip.
      </CardContent>
      <CardFooter className="flex flex-wrap gap-3">
        <Button asChild size="sm">
          <Link href="/links">Permits & Advisories</Link>
        </Button>
        <Button asChild size="sm" variant="outline">
          <Link href="/marketplace">Book Stays & Guides</Link>
        </Button>
        <Button asChild size="sm" variant="outline">
          <Link href="/contact">Tourism Helpline</Link>
        </Button>
      </CardFooter>
    </Card>
  )
}
