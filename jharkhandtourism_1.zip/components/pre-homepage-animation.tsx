"use client"

import { useEffect, useState } from "react"

interface PreHomepageAnimationProps {
  onComplete: () => void
}

export default function PreHomepageAnimation({ onComplete }: PreHomepageAnimationProps) {
  const [isVisible, setIsVisible] = useState(true)

  useEffect(() => {
    // Check if animation has been shown in this session
    const hasShownAnimation = sessionStorage.getItem("jharkhand-animation-shown")

    if (hasShownAnimation) {
      setIsVisible(false)
      onComplete()
      return
    }

    // Set animation as shown for this session
    sessionStorage.setItem("jharkhand-animation-shown", "true")

    // Complete animation after 5 seconds
    const timer = setTimeout(() => {
      setIsVisible(false)
      onComplete()
    }, 5000)

    return () => clearTimeout(timer)
  }, [onComplete])

  if (!isVisible) return null

  return (
    <div className="pre-homepage-animation">
      {/* Tribal patterns background */}
      <div className="tribal-pattern" />

      {/* Waterfall effect */}
      <div className="waterfall-effect" />
      <div className="waterfall-effect" style={{ left: "60%", animationDelay: "1.2s" }} />

      {/* Hills silhouette */}
      <div className="hills-silhouette" />

      {/* Temple silhouette */}
      <div className="temple-silhouette" />

      {/* Wildlife elements */}
      <div className="wildlife-elephant" />
      <div className="wildlife-bird" />
      <div className="wildlife-bird" style={{ top: "15%", right: "-40px", animationDelay: "3.2s" }} />

      {/* Logo and tagline */}
      <div className="logo-container">
        <div className="logo-text">Jharkhand Tourism</div>
        <div className="tagline">Experience the Soul of India</div>
      </div>
    </div>
  )
}
