"use client"

import { SiteHeader } from "@/components/site-header"
import { SiteFooter } from "@/components/site-footer"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Label } from "@/components/ui/label"
import { Input } from "@/components/ui/input"
import { Switch } from "@/components/ui/switch"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { useTheme } from "next-themes"
import { useState, useEffect } from "react"

export default function SettingsPage() {
  const { theme, setTheme } = useTheme()
  const [mounted, setMounted] = useState(false)

  useEffect(() => {
    setMounted(true)
  }, [])

  if (!mounted) {
    return null
  }

  return (
    <div className="min-h-screen flex flex-col bg-background text-foreground font-sans">
      <SiteHeader />
      <main id="main" className="flex-1 mx-auto max-w-6xl px-4 sm:px-6 py-10">
        <header className="mb-8 fade-in">
          <h1 className="text-3xl font-semibold text-primary text-balance">Settings</h1>
          <p className="mt-2 text-foreground/90">
            Configure your account and application preferences for the best experience.
          </p>
        </header>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          <Card className="fade-in fade-in-delay-1">
            <CardHeader>
              <CardTitle>Account Information</CardTitle>
              <CardDescription>Update your basic account details</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div>
                <Label htmlFor="acc-name">Display Name</Label>
                <Input id="acc-name" defaultValue="Ravi Kumar" />
              </div>
              <div>
                <Label htmlFor="acc-email">Email Address</Label>
                <Input id="acc-email" type="email" defaultValue="ravi.kumar@example.com" />
              </div>
              <div>
                <Label htmlFor="acc-phone">Phone Number</Label>
                <Input id="acc-phone" defaultValue="+91 9876 543210" />
              </div>
              <Button type="button" className="transition-colors">
                Save Changes
              </Button>
            </CardContent>
          </Card>

          <Card className="fade-in fade-in-delay-1">
            <CardHeader>
              <CardTitle>Appearance</CardTitle>
              <CardDescription>Customize how the website looks and feels</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div>
                <Label htmlFor="theme-select">Theme</Label>
                <Select value={theme} onValueChange={setTheme}>
                  <SelectTrigger>
                    <SelectValue placeholder="Select theme" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="light">Light</SelectItem>
                    <SelectItem value="dark">Dark</SelectItem>
                    <SelectItem value="system">System</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div className="flex items-center justify-between">
                <div>
                  <p className="font-medium">Reduced Motion</p>
                  <p className="text-sm text-muted-foreground">Minimize animations</p>
                </div>
                <Switch id="reduced-motion" />
              </div>
              <div className="flex items-center justify-between">
                <div>
                  <p className="font-medium">High Contrast</p>
                  <p className="text-sm text-muted-foreground">Improve readability</p>
                </div>
                <Switch id="high-contrast" />
              </div>
            </CardContent>
          </Card>

          <Card className="fade-in fade-in-delay-2">
            <CardHeader>
              <CardTitle>Security & Privacy</CardTitle>
              <CardDescription>Protect your account and data</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div>
                <Label htmlFor="current-pass">Current Password</Label>
                <Input id="current-pass" type="password" />
              </div>
              <div>
                <Label htmlFor="new-pass">New Password</Label>
                <Input id="new-pass" type="password" />
              </div>
              <div>
                <Label htmlFor="confirm-pass">Confirm New Password</Label>
                <Input id="confirm-pass" type="password" />
              </div>
              <Button type="button" className="transition-colors">
                Change Password
              </Button>

              <div className="pt-4 border-t">
                <div className="flex items-center justify-between mb-3">
                  <div>
                    <p className="font-medium">Two-Factor Authentication</p>
                    <p className="text-sm text-muted-foreground">Add extra security to your account</p>
                  </div>
                  <Switch id="two-factor" />
                </div>
                <Button variant="outline" size="sm">
                  Setup 2FA
                </Button>
              </div>
            </CardContent>
          </Card>

          <Card className="fade-in fade-in-delay-2">
            <CardHeader>
              <CardTitle>Privacy & Data</CardTitle>
              <CardDescription>Control how your information is used</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex items-center justify-between">
                <div>
                  <p className="font-medium">Analytics & Usage Data</p>
                  <p className="text-sm text-muted-foreground">Help improve our services</p>
                </div>
                <Switch id="privacy-analytics" defaultChecked />
              </div>
              <div className="flex items-center justify-between">
                <div>
                  <p className="font-medium">Personalized Recommendations</p>
                  <p className="text-sm text-muted-foreground">Tailor content to your preferences</p>
                </div>
                <Switch id="privacy-recs" defaultChecked />
              </div>
              <div className="flex items-center justify-between">
                <div>
                  <p className="font-medium">Location Services</p>
                  <p className="text-sm text-muted-foreground">Show nearby attractions</p>
                </div>
                <Switch id="privacy-location" />
              </div>
              <div className="pt-4 border-t">
                <Button variant="outline" size="sm" className="mr-2 bg-transparent">
                  Download My Data
                </Button>
                <Button variant="outline" size="sm">
                  Delete My Data
                </Button>
              </div>
            </CardContent>
          </Card>

          <Card className="fade-in fade-in-delay-3">
            <CardHeader>
              <CardTitle>Notifications</CardTitle>
              <CardDescription>Choose how and when you want to be contacted</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex items-center justify-between">
                <div>
                  <p className="font-medium">Email Notifications</p>
                  <p className="text-sm text-muted-foreground">News, events, and updates</p>
                </div>
                <Switch id="comm-email" defaultChecked />
              </div>
              <div className="flex items-center justify-between">
                <div>
                  <p className="font-medium">SMS Notifications</p>
                  <p className="text-sm text-muted-foreground">Booking confirmations and reminders</p>
                </div>
                <Switch id="comm-sms" defaultChecked />
              </div>
              <div className="flex items-center justify-between">
                <div>
                  <p className="font-medium">Push Notifications</p>
                  <p className="text-sm text-muted-foreground">Real-time travel advisories</p>
                </div>
                <Switch id="comm-push" />
              </div>
              <div className="flex items-center justify-between">
                <div>
                  <p className="font-medium">Marketing Communications</p>
                  <p className="text-sm text-muted-foreground">Special offers and promotions</p>
                </div>
                <Switch id="comm-marketing" />
              </div>
            </CardContent>
          </Card>

          <Card className="fade-in fade-in-delay-3">
            <CardHeader>
              <CardTitle>Language & Region</CardTitle>
              <CardDescription>Customize your regional preferences</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div>
                <Label htmlFor="language">Language</Label>
                <Select defaultValue="en">
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="en">English</SelectItem>
                    <SelectItem value="hi">हिंदी (Hindi)</SelectItem>
                    <SelectItem value="sa">ᱥᱟᱱᱛᱟᱲᱤ (Santali)</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div>
                <Label htmlFor="timezone">Timezone</Label>
                <Select defaultValue="ist">
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="ist">India Standard Time (IST)</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div>
                <Label htmlFor="currency">Currency</Label>
                <Select defaultValue="inr">
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="inr">Indian Rupee (₹)</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </CardContent>
          </Card>
        </div>

        <section className="mt-8 fade-in fade-in-delay-4" aria-labelledby="danger-zone">
          <h2 id="danger-zone" className="sr-only">
            Danger Zone
          </h2>
          <Card className="border-destructive/50">
            <CardHeader>
              <CardTitle className="text-destructive">Danger Zone</CardTitle>
              <CardDescription>Irreversible actions that will permanently affect your account</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="p-4 rounded-lg bg-destructive/10 border border-destructive/20">
                <h3 className="font-medium text-destructive mb-2">Delete Account</h3>
                <p className="text-sm text-muted-foreground mb-3">
                  This will permanently delete your account, profile, travel history, bookings, and all associated data.
                  This action cannot be undone.
                </p>
                <Button variant="destructive" size="sm">
                  Delete My Account
                </Button>
              </div>
              <div className="p-4 rounded-lg bg-muted/50 border">
                <h3 className="font-medium mb-2">Export Data</h3>
                <p className="text-sm text-muted-foreground mb-3">
                  Download a copy of your data before making any permanent changes.
                </p>
                <Button variant="outline" size="sm">
                  Export My Data
                </Button>
              </div>
            </CardContent>
          </Card>
        </section>
      </main>
      <SiteFooter />
    </div>
  )
}
