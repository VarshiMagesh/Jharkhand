import { SiteHeader } from "@/components/site-header"
import { SiteFooter } from "@/components/site-footer"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"

export default function DashboardPage() {
  return (
    <div className="min-h-screen flex flex-col bg-background text-foreground font-sans">
      <SiteHeader />
      <main id="main" className="flex-1 mx-auto max-w-6xl px-4 sm:px-6 py-10">
        <header className="mb-8">
          <h1 className="text-3xl font-semibold text-primary text-balance">Your Tourism Dashboard</h1>
          <p className="mt-2 text-foreground/90 leading-relaxed">
            Plan trips, track bookings, and access official resources for a smooth visit to Jharkhand.
          </p>
        </header>

        {/* Overview Stats */}
        <section aria-labelledby="overview-heading" className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-10">
          <h2 id="overview-heading" className="sr-only">
            Overview
          </h2>

          <Card>
            <CardHeader className="pb-2">
              <CardDescription>Trips Planned</CardDescription>
              <CardTitle className="text-2xl">2</CardTitle>
            </CardHeader>
            <CardContent className="pt-0">
              <Badge variant="secondary">Next: 12 Oct</Badge>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="pb-2">
              <CardDescription>Bookings</CardDescription>
              <CardTitle className="text-2xl">3</CardTitle>
            </CardHeader>
            <CardContent className="pt-0">
              <p className="text-sm text-foreground/70">Hotels, Guides</p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="pb-2">
              <CardDescription>Saved Spots</CardDescription>
              <CardTitle className="text-2xl">8</CardTitle>
            </CardHeader>
            <CardContent className="pt-0">
              <p className="text-sm text-foreground/70">Popular & offbeat</p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="pb-2">
              <CardDescription>Alerts</CardDescription>
              <CardTitle className="text-2xl">1</CardTitle>
            </CardHeader>
            <CardContent className="pt-0">
              <Badge className="bg-destructive text-white">Advisory</Badge>
            </CardContent>
          </Card>
        </section>

        {/* Upcoming Trips + Recent Bookings */}
        <section className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-10" aria-labelledby="trips-bookings">
          <h2 id="trips-bookings" className="sr-only">
            Trips and Bookings
          </h2>

          <Card className="md:col-span-2">
            <CardHeader>
              <CardTitle className="text-xl">Upcoming Trips</CardTitle>
              <CardDescription>Keep track of your itinerary and documents</CardDescription>
            </CardHeader>
            <CardContent>
              <ul className="divide-y divide-border">
                <li className="py-3 flex items-center justify-between">
                  <div>
                    <p className="font-medium">Ranchi City & Dassam Falls</p>
                    <p className="text-sm text-foreground/70">12–14 Oct · 2 nights · 3 travellers</p>
                  </div>
                  <div className="flex items-center gap-2">
                    <Badge variant="secondary">Itinerary ready</Badge>
                    <Button size="sm" variant="outline">
                      View
                    </Button>
                  </div>
                </li>
                <li className="py-3 flex items-center justify-between">
                  <div>
                    <p className="font-medium">Netarhat & Betla National Park</p>
                    <p className="text-sm text-foreground/70">05–08 Nov · 3 nights · 2 travellers</p>
                  </div>
                  <div className="flex items-center gap-2">
                    <Badge>Pending booking</Badge>
                    <Button size="sm">Complete</Button>
                  </div>
                </li>
              </ul>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle className="text-xl">Recent Bookings</CardTitle>
              <CardDescription>Latest confirmations at a glance</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                <div className="flex items-start justify-between">
                  <div>
                    <p className="font-medium">Hotel in Ranchi</p>
                    <p className="text-sm text-foreground/70">Check-in 12 Oct · 2 nights</p>
                  </div>
                  <Badge className="bg-green-600 text-white">Confirmed</Badge>
                </div>
                <div className="flex items-start justify-between">
                  <div>
                    <p className="font-medium">Local Guide (Dassam Falls)</p>
                    <p className="text-sm text-foreground/70">13 Oct · 10:00 AM</p>
                  </div>
                  <Badge variant="secondary">Voucher</Badge>
                </div>
                <div className="flex items-start justify-between">
                  <div>
                    <p className="font-medium">Safari (Betla)</p>
                    <p className="text-sm text-foreground/70">06 Nov · Morning slot</p>
                  </div>
                  <Badge className="bg-amber-600 text-white">Pending</Badge>
                </div>
              </div>
            </CardContent>
          </Card>
        </section>

        {/* Saved Destinations */}
        <section aria-labelledby="saved-destinations" className="mb-10">
          <div className="flex items-center justify-between mb-3">
            <h2 id="saved-destinations" className="text-xl font-semibold">
              Saved Destinations
            </h2>
            <Button variant="outline" size="sm">
              View all
            </Button>
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-4">
            <Card>
              <CardContent className="p-0">
                <img
                  src="/dassam-falls-jharkhand.png"
                  alt="Dassam Falls scenic view"
                  className="w-full h-40 object-cover"
                />
              </CardContent>
              <CardHeader className="py-3">
                <CardTitle className="text-base">Dassam Falls</CardTitle>
                <CardDescription>Near Ranchi · Nature</CardDescription>
              </CardHeader>
            </Card>

            <Card>
              <CardContent className="p-0">
                <img
                  src="/betla-national-park-jharkhand.png"
                  alt="Betla National Park forest landscape"
                  className="w-full h-40 object-cover"
                />
              </CardContent>
              <CardHeader className="py-3">
                <CardTitle className="text-base">Betla National Park</CardTitle>
                <CardDescription>Palamu · Wildlife</CardDescription>
              </CardHeader>
            </Card>

            <Card>
              <CardContent className="p-0">
                <img
                  src="/netarhat-sunset-jharkhand.png"
                  alt="Netarhat sunset viewpoint"
                  className="w-full h-40 object-cover"
                />
              </CardContent>
              <CardHeader className="py-3">
                <CardTitle className="text-base">Netarhat</CardTitle>
                <CardDescription>Latehar · Hill Station</CardDescription>
              </CardHeader>
            </Card>
          </div>
        </section>

        {/* Alerts and Helplines */}
        <section className="grid grid-cols-1 md:grid-cols-2 gap-6" aria-labelledby="alerts-helplines">
          <h2 id="alerts-helplines" className="sr-only">
            Alerts and Helplines
          </h2>

          <Card>
            <CardHeader>
              <CardTitle className="text-xl">Travel Alerts</CardTitle>
              <CardDescription>Official advisories and safety updates</CardDescription>
            </CardHeader>
            <CardContent>
              <ul className="space-y-3">
                <li className="flex items-start justify-between gap-4">
                  <div>
                    <p className="font-medium">Seasonal advisory for waterfalls</p>
                    <p className="text-sm text-foreground/70">Follow local guidance during monsoon months.</p>
                  </div>
                  <Badge className="bg-amber-600 text-white">Advisory</Badge>
                </li>
                <li className="flex items-start justify-between gap-4">
                  <div>
                    <p className="font-medium">Park timings updated</p>
                    <p className="text-sm text-foreground/70">Betla National Park morning slots start at 6:00 AM.</p>
                  </div>
                  <Badge variant="secondary">Update</Badge>
                </li>
              </ul>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle className="text-xl">Helplines & Quick Links</CardTitle>
              <CardDescription>Trusted contacts and resources</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div>
                  <p className="font-medium">Tourism Helpline</p>
                  <p className="text-sm text-foreground/70">1800-XXXX-XXX (9 AM – 6 PM)</p>
                </div>
                <div>
                  <p className="font-medium">Emergency</p>
                  <p className="text-sm text-foreground/70">112 (24x7)</p>
                </div>
                <div className="flex items-center gap-2">
                  <Button variant="outline" size="sm">
                    Official Website
                  </Button>
                  <Button size="sm">Plan Your Visit</Button>
                </div>
              </div>
            </CardContent>
          </Card>
        </section>
      </main>
      <SiteFooter />
    </div>
  )
}
