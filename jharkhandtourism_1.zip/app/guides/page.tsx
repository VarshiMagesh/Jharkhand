"use client"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Input } from "@/components/ui/input"
import { Textarea } from "@/components/ui/textarea"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Star, MapPin, Clock, Phone, MessageCircle, CheckCircle } from "lucide-react"
import { useState } from "react"
import { SiteHeader } from "@/components/site-header"
import { SiteFooter } from "@/components/site-footer"

const guides = [
  {
    id: 1,
    name: "Pawan Kumar",
    area: "Betla • Wildlife",
    desc: "Safari planning, animal tracking, safety briefings",
    tags: ["Wildlife", "Hindi", "English"],
    avatar: "/indian-male-guide.jpg",
    rating: 4.8,
    totalReviews: 127,
    experience: "8 years",
    languages: ["Hindi", "English", "Santhali"],
    specialties: ["Tiger tracking", "Bird watching", "Photography tours"],
    pricePerDay: 2500,
    availability: "Available",
    phone: "+91-9876543210",
    reviews: [
      {
        id: 1,
        user: "Rajesh M.",
        rating: 5,
        comment: "Excellent guide! Spotted 2 tigers and learned so much about wildlife. Highly recommended!",
        date: "2 weeks ago",
        avatar: "/placeholder-6bl8w.png",
      },
      {
        id: 2,
        user: "Priya S.",
        rating: 5,
        comment: "Pawan's knowledge of animal behavior is incredible. Made our safari unforgettable.",
        date: "1 month ago",
        avatar: "/placeholder-t347d.png",
      },
      {
        id: 3,
        user: "David L.",
        rating: 4,
        comment: "Great experience, very professional and safety-conscious. Good English communication.",
        date: "2 months ago",
        avatar: "/placeholder-fzsdh.png",
      },
    ],
  },
  {
    id: 2,
    name: "Anita Devi",
    area: "Netarhat • Trekking",
    desc: "Hiking trails, sunrise/sunset points, local flora",
    tags: ["Trekking", "Hindi"],
    avatar: "/placeholder-3bj1s.png",
    rating: 4.9,
    totalReviews: 89,
    experience: "6 years",
    languages: ["Hindi", "English", "Nagpuri"],
    specialties: ["Mountain trekking", "Sunrise tours", "Flora identification"],
    pricePerDay: 2000,
    availability: "Available",
    phone: "+91-9876543211",
    reviews: [
      {
        id: 1,
        user: "Amit K.",
        rating: 5,
        comment: "Amazing sunrise trek! Anita knows all the best spots and is very encouraging.",
        date: "1 week ago",
        avatar: "/placeholder-wl651.png",
      },
      {
        id: 2,
        user: "Sarah J.",
        rating: 5,
        comment: "Best trekking guide ever! Made the challenging trails feel manageable and fun.",
        date: "3 weeks ago",
        avatar: "/placeholder-dgsgt.png",
      },
    ],
  },
  {
    id: 3,
    name: "Sanjay Singh",
    area: "Ranchi • Heritage",
    desc: "City heritage walks and cultural tours",
    tags: ["Heritage", "English"],
    avatar: "/placeholder-d0rkf.png",
    rating: 4.7,
    totalReviews: 156,
    experience: "10 years",
    languages: ["English", "Hindi", "Bengali"],
    specialties: ["Historical sites", "Cultural stories", "Architecture"],
    pricePerDay: 1800,
    availability: "Busy until Dec 25",
    phone: "+91-9876543212",
    reviews: [
      {
        id: 1,
        user: "Meera P.",
        rating: 5,
        comment: "Sanjay's storytelling brought history to life. Learned so much about Jharkhand's heritage!",
        date: "5 days ago",
        avatar: "/placeholder-t347d.png",
      },
      {
        id: 2,
        user: "Robert M.",
        rating: 4,
        comment: "Very knowledgeable about local history and culture. Great English communication.",
        date: "2 weeks ago",
        avatar: "/placeholder-fzsdh.png",
      },
    ],
  },
]

export default function GuidesPage() {
  const [selectedGuide, setSelectedGuide] = useState(null)
  const [bookingStep, setBookingStep] = useState(1)
  const [bookingData, setBookingData] = useState({
    dates: "",
    duration: "",
    groupSize: "",
    requirements: "",
  })

  const handleBookGuide = (guide) => {
    setSelectedGuide(guide)
    setBookingStep(1)
  }

  const handleBookingSubmit = () => {
    console.log("Booking submitted:", { guide: selectedGuide, ...bookingData })
    setSelectedGuide(null)
    setBookingStep(1)
  }

  return (
    <div className="min-h-screen flex flex-col bg-background text-foreground font-sans">
      <SiteHeader />
      <main className="flex-1 container mx-auto px-4 py-8">
        <header className="mb-8">
          <h1 className="text-3xl font-semibold text-pretty">Hire Certified Guides</h1>
          <p className="text-muted-foreground max-w-2xl mt-2">
            Certified local guides for safe exploration—heritage walks, wildlife safaris, treks, and cultural tours.
          </p>
        </header>

        <section className="mb-6 grid grid-cols-1 md:grid-cols-4 gap-4">
          <Input placeholder="Search guides by name or area" aria-label="Search guides" />
          <Select>
            <SelectTrigger aria-label="Select expertise">
              <SelectValue placeholder="Expertise" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="wildlife">Wildlife</SelectItem>
              <SelectItem value="heritage">Heritage</SelectItem>
              <SelectItem value="trekking">Trekking</SelectItem>
              <SelectItem value="culture">Culture</SelectItem>
            </SelectContent>
          </Select>
          <Select>
            <SelectTrigger aria-label="Select language">
              <SelectValue placeholder="Language" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="en">English</SelectItem>
              <SelectItem value="hi">Hindi</SelectItem>
              <SelectItem value="bn">Bengali</SelectItem>
              <SelectItem value="regional">Regional</SelectItem>
            </SelectContent>
          </Select>
          <Select>
            <SelectTrigger aria-label="Select location">
              <SelectValue placeholder="Location" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="ranchi">Ranchi</SelectItem>
              <SelectItem value="betla">Betla</SelectItem>
              <SelectItem value="netarhat">Netarhat</SelectItem>
              <SelectItem value="deoghar">Deoghar</SelectItem>
            </SelectContent>
          </Select>
        </section>

        <section aria-labelledby="guide-list" className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          <h2 id="guide-list" className="sr-only">
            Certified guides
          </h2>

          {guides.map((guide) => (
            <Card key={guide.id} className="hover:shadow-lg transition-shadow">
              <CardHeader className="pb-4">
                <div className="flex items-start gap-4">
                  <Avatar className="h-16 w-16">
                    <AvatarImage src={guide.avatar || "/placeholder.svg"} alt={guide.name} />
                    <AvatarFallback>
                      {guide.name
                        .split(" ")
                        .map((n) => n[0])
                        .join("")}
                    </AvatarFallback>
                  </Avatar>
                  <div className="flex-1">
                    <div className="flex items-center justify-between">
                      <CardTitle className="text-lg">{guide.name}</CardTitle>
                      <Badge
                        variant={guide.availability === "Available" ? "default" : "secondary"}
                        className={guide.availability === "Available" ? "bg-green-100 text-green-800" : ""}
                      >
                        {guide.availability}
                      </Badge>
                    </div>
                    <CardDescription className="flex items-center gap-1 mt-1">
                      <MapPin className="w-4 h-4" />
                      {guide.area}
                    </CardDescription>
                    <div className="flex items-center gap-2 mt-2">
                      <div className="flex items-center gap-1">
                        <Star className="w-4 h-4 fill-yellow-400 text-yellow-400" />
                        <span className="text-sm font-medium">{guide.rating}</span>
                      </div>
                      <span className="text-sm text-muted-foreground">({guide.totalReviews} reviews)</span>
                    </div>
                  </div>
                </div>
              </CardHeader>
              <CardContent className="space-y-4">
                <p className="text-sm text-muted-foreground">{guide.desc}</p>

                <div className="flex flex-wrap gap-1">
                  {guide.tags.map((tag) => (
                    <Badge key={tag} variant="outline" className="text-xs">
                      {tag}
                    </Badge>
                  ))}
                </div>

                <div className="flex items-center justify-between text-sm">
                  <div className="flex items-center gap-1 text-muted-foreground">
                    <Clock className="w-4 h-4" />
                    {guide.experience} exp.
                  </div>
                  <div className="font-semibold text-primary">₹{guide.pricePerDay}/day</div>
                </div>

                <div className="flex gap-2">
                  <Button
                    onClick={() => handleBookGuide(guide)}
                    className="flex-1"
                    disabled={guide.availability !== "Available"}
                  >
                    Book Now
                  </Button>
                  <Dialog>
                    <DialogTrigger asChild>
                      <Button variant="outline" size="sm">
                        Reviews
                      </Button>
                    </DialogTrigger>
                    <DialogContent className="max-w-2xl max-h-[80vh] overflow-y-auto">
                      <DialogHeader>
                        <DialogTitle className="flex items-center gap-3">
                          <Avatar className="h-12 w-12">
                            <AvatarImage src={guide.avatar || "/placeholder.svg"} alt={guide.name} />
                            <AvatarFallback>
                              {guide.name
                                .split(" ")
                                .map((n) => n[0])
                                .join("")}
                            </AvatarFallback>
                          </Avatar>
                          <div>
                            <div>{guide.name}</div>
                            <div className="flex items-center gap-2 text-sm text-muted-foreground">
                              <Star className="w-4 h-4 fill-yellow-400 text-yellow-400" />
                              {guide.rating} ({guide.totalReviews} reviews)
                            </div>
                          </div>
                        </DialogTitle>
                      </DialogHeader>

                      <div className="space-y-4">
                        <div className="grid grid-cols-2 gap-4 p-4 bg-accent/5 rounded-lg">
                          <div>
                            <div className="text-sm text-muted-foreground">Experience</div>
                            <div className="font-medium">{guide.experience}</div>
                          </div>
                          <div>
                            <div className="text-sm text-muted-foreground">Languages</div>
                            <div className="font-medium">{guide.languages.join(", ")}</div>
                          </div>
                        </div>

                        <div>
                          <h4 className="font-semibold mb-2">Specialties</h4>
                          <div className="flex flex-wrap gap-2">
                            {guide.specialties.map((specialty, index) => (
                              <Badge key={index} variant="secondary">
                                {specialty}
                              </Badge>
                            ))}
                          </div>
                        </div>

                        <div>
                          <h4 className="font-semibold mb-4">Recent Reviews</h4>
                          <div className="space-y-4">
                            {guide.reviews.map((review) => (
                              <div key={review.id} className="border-b pb-4 last:border-b-0">
                                <div className="flex items-start gap-3">
                                  <Avatar className="h-8 w-8">
                                    <AvatarImage src={review.avatar || "/placeholder.svg"} alt={review.user} />
                                    <AvatarFallback>{review.user[0]}</AvatarFallback>
                                  </Avatar>
                                  <div className="flex-1">
                                    <div className="flex items-center gap-2 mb-1">
                                      <span className="font-medium text-sm">{review.user}</span>
                                      <div className="flex">
                                        {[...Array(5)].map((_, i) => (
                                          <Star
                                            key={i}
                                            className={`w-3 h-3 ${i < review.rating ? "fill-yellow-400 text-yellow-400" : "text-gray-300"}`}
                                          />
                                        ))}
                                      </div>
                                      <span className="text-xs text-muted-foreground">{review.date}</span>
                                    </div>
                                    <p className="text-sm text-foreground/80">{review.comment}</p>
                                  </div>
                                </div>
                              </div>
                            ))}
                          </div>
                        </div>
                      </div>
                    </DialogContent>
                  </Dialog>
                </div>
              </CardContent>
            </Card>
          ))}
        </section>

        <Dialog open={!!selectedGuide} onOpenChange={() => setSelectedGuide(null)}>
          <DialogContent className="max-w-md">
            <DialogHeader>
              <DialogTitle>Book Your Guide</DialogTitle>
              <DialogDescription>Complete your booking with {selectedGuide?.name}</DialogDescription>
            </DialogHeader>

            {selectedGuide && (
              <div className="space-y-6">
                <div className="flex items-center gap-3 p-4 bg-accent/5 rounded-lg">
                  <Avatar className="h-12 w-12">
                    <AvatarImage src={selectedGuide.avatar || "/placeholder.svg"} alt={selectedGuide.name} />
                    <AvatarFallback>
                      {selectedGuide.name
                        .split(" ")
                        .map((n) => n[0])
                        .join("")}
                    </AvatarFallback>
                  </Avatar>
                  <div className="flex-1">
                    <div className="font-semibold">{selectedGuide.name}</div>
                    <div className="text-sm text-muted-foreground flex items-center gap-1">
                      <MapPin className="w-3 h-3" />
                      {selectedGuide.area}
                    </div>
                    <div className="flex items-center gap-2 mt-1">
                      <div className="flex items-center gap-1">
                        <Star className="w-3 h-3 fill-yellow-400 text-yellow-400" />
                        <span className="text-xs">{selectedGuide.rating}</span>
                      </div>
                      <span className="text-xs font-semibold text-primary">₹{selectedGuide.pricePerDay}/day</span>
                    </div>
                  </div>
                </div>

                {bookingStep === 1 && (
                  <div className="space-y-4">
                    <div>
                      <label className="text-sm font-medium">Preferred Dates</label>
                      <Input
                        type="date"
                        value={bookingData.dates}
                        onChange={(e) => setBookingData({ ...bookingData, dates: e.target.value })}
                        className="mt-1"
                      />
                    </div>
                    <div>
                      <label className="text-sm font-medium">Duration</label>
                      <Select onValueChange={(value) => setBookingData({ ...bookingData, duration: value })}>
                        <SelectTrigger className="mt-1">
                          <SelectValue placeholder="Select duration" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="half-day">Half Day (4 hours)</SelectItem>
                          <SelectItem value="full-day">Full Day (8 hours)</SelectItem>
                          <SelectItem value="2-days">2 Days</SelectItem>
                          <SelectItem value="3-days">3 Days</SelectItem>
                          <SelectItem value="custom">Custom</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                    <div>
                      <label className="text-sm font-medium">Group Size</label>
                      <Select onValueChange={(value) => setBookingData({ ...bookingData, groupSize: value })}>
                        <SelectTrigger className="mt-1">
                          <SelectValue placeholder="Number of people" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="1">1 person</SelectItem>
                          <SelectItem value="2">2 people</SelectItem>
                          <SelectItem value="3-5">3-5 people</SelectItem>
                          <SelectItem value="6-10">6-10 people</SelectItem>
                          <SelectItem value="10+">10+ people</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                    <div>
                      <label className="text-sm font-medium">Special Requirements</label>
                      <Textarea
                        placeholder="Any specific interests, accessibility needs, or requests..."
                        value={bookingData.requirements}
                        onChange={(e) => setBookingData({ ...bookingData, requirements: e.target.value })}
                        className="mt-1"
                      />
                    </div>
                    <Button
                      onClick={() => setBookingStep(2)}
                      className="w-full"
                      disabled={!bookingData.dates || !bookingData.duration || !bookingData.groupSize}
                    >
                      Continue to Contact
                    </Button>
                  </div>
                )}

                {bookingStep === 2 && (
                  <div className="space-y-4">
                    <div className="text-center p-4 bg-green-50 rounded-lg border border-green-200">
                      <CheckCircle className="w-8 h-8 text-green-600 mx-auto mb-2" />
                      <h3 className="font-semibold text-green-800">Booking Request Submitted!</h3>
                      <p className="text-sm text-green-700 mt-1">
                        {selectedGuide.name} will contact you within 2 hours to confirm availability and details.
                      </p>
                    </div>

                    <div className="space-y-3">
                      <div className="flex items-center gap-3 p-3 border rounded-lg">
                        <Phone className="w-5 h-5 text-primary" />
                        <div>
                          <div className="font-medium">Direct Contact</div>
                          <div className="text-sm text-muted-foreground">{selectedGuide.phone}</div>
                        </div>
                      </div>

                      <div className="flex items-center gap-3 p-3 border rounded-lg">
                        <MessageCircle className="w-5 h-5 text-primary" />
                        <div>
                          <div className="font-medium">WhatsApp Available</div>
                          <div className="text-sm text-muted-foreground">Quick responses guaranteed</div>
                        </div>
                      </div>
                    </div>

                    <Button onClick={handleBookingSubmit} className="w-full">
                      Done
                    </Button>
                  </div>
                )}
              </div>
            )}
          </DialogContent>
        </Dialog>

        <section aria-labelledby="custom-request" className="mt-10">
          <h2 id="custom-request" className="text-xl font-medium">
            Custom request
          </h2>
          <p className="text-muted-foreground mt-1">Describe your plan and we'll match a certified guide.</p>
          <div className="mt-4 grid gap-3 max-w-xl">
            <Input placeholder="Your name" />
            <Input placeholder="Email" type="email" />
            <Textarea placeholder="Tell us your dates, group size, and interests…" />
            <Button className="w-fit">Submit request</Button>
          </div>
        </section>
      </main>
      <SiteFooter />
    </div>
  )
}
