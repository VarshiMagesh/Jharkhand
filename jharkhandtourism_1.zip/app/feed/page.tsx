"use client"

import { SiteHeader } from "@/components/site-header"
import { SiteFooter } from "@/components/site-footer"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { useState } from "react"

const feedItems = [
  {
    id: 1,
    type: "advisory",
    title: "Seasonal waterfall safety guidance",
    content: "Follow signage and local guidance during post-monsoon flows. Water levels can change rapidly.",
    author: "Jharkhand Tourism Board",
    date: "Sep 12",
    priority: "high",
    image: "/waterfall-safety-advisory-jharkhand.jpg",
    engagement: { likes: 45, shares: 12, comments: 8 },
  },
  {
    id: 2,
    type: "event",
    title: "Sarhul Festival Celebrations 2024",
    content: "Join the vibrant spring festival celebrating nature and new beginnings across tribal communities.",
    author: "Cultural Affairs Dept",
    date: "Oct 05",
    priority: "medium",
    image: "/sarhul-festival-jharkhand-tribal-celebration.jpg",
    engagement: { likes: 128, shares: 34, comments: 22 },
  },
  {
    id: 3,
    type: "announcement",
    title: "Betla National Park timing updates",
    content: "Morning safaris now start at 6:00 AM. Evening slots available until 5:30 PM. Book in advance.",
    author: "Forest Department",
    date: "Oct 10",
    priority: "medium",
    image: "/betla-national-park-jharkhand-wildlife.png",
    engagement: { likes: 67, shares: 18, comments: 15 },
  },
  {
    id: 4,
    type: "news",
    title: "New eco-trails introduced in Netarhat",
    content: "Community-led circuits with trained local guides now available. Experience sustainable tourism.",
    author: "Eco-Tourism Initiative",
    date: "Oct 18",
    priority: "low",
    image: "/netarhat-eco-trails-jharkhand-sustainable-tourism.jpg",
    engagement: { likes: 89, shares: 25, comments: 11 },
  },
  {
    id: 5,
    type: "traveler",
    title: "Amazing wildlife spotting at Hazaribagh",
    content: "Spotted a leopard family during early morning safari! The sanctuary is truly a hidden gem.",
    author: "Priya Sharma",
    date: "Oct 20",
    priority: "low",
    image: "/leopard-hazaribagh-wildlife-sanctuary-jharkhand.jpg",
    engagement: { likes: 156, shares: 42, comments: 28 },
  },
  {
    id: 6,
    type: "advisory",
    title: "Monsoon road conditions update",
    content: "Some hill routes may be affected by recent rainfall. Check conditions before traveling.",
    author: "Transport Authority",
    date: "Oct 22",
    priority: "high",
    image: "/monsoon-road-conditions-jharkhand-hills.jpg",
    engagement: { likes: 34, shares: 15, comments: 6 },
  },
]

export default function FeedPage() {
  const [searchTerm, setSearchTerm] = useState("")
  const [selectedFilter, setSelectedFilter] = useState("all")

  const filteredItems = feedItems.filter((item) => {
    const matchesSearch =
      item.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
      item.content.toLowerCase().includes(searchTerm.toLowerCase())
    const matchesFilter = selectedFilter === "all" || item.type === selectedFilter
    return matchesSearch && matchesFilter
  })

  const getPriorityColor = (priority: string) => {
    switch (priority) {
      case "high":
        return "destructive"
      case "medium":
        return "secondary"
      default:
        return "outline"
    }
  }

  const getTypeIcon = (type: string) => {
    switch (type) {
      case "advisory":
        return "⚠️"
      case "event":
        return "🎉"
      case "announcement":
        return "📢"
      case "news":
        return "📰"
      case "traveler":
        return "📸"
      default:
        return "ℹ️"
    }
  }

  return (
    <div className="min-h-screen flex flex-col bg-background text-foreground font-sans">
      <SiteHeader />
      <main id="main" className="flex-1 mx-auto max-w-4xl px-4 sm:px-6 py-10">
        <header className="mb-8 fade-in">
          <h1 className="text-3xl font-semibold text-primary text-balance">Community Feed</h1>
          <p className="mt-2 text-foreground/90">
            Stay updated with official advisories, events, and traveler stories from across Jharkhand.
          </p>
        </header>

        <section className="mb-8 fade-in fade-in-delay-1">
          <div className="flex flex-col sm:flex-row gap-4 mb-6">
            <Input
              placeholder="Search updates..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="flex-1"
            />
          </div>
          <div className="flex flex-wrap gap-2">
            {[
              { key: "all", label: "All Updates" },
              { key: "advisory", label: "Advisories" },
              { key: "event", label: "Events" },
              { key: "announcement", label: "Announcements" },
              { key: "news", label: "News" },
              { key: "traveler", label: "Traveler Stories" },
            ].map((filter) => (
              <Button
                key={filter.key}
                variant={selectedFilter === filter.key ? "default" : "outline"}
                size="sm"
                onClick={() => setSelectedFilter(filter.key)}
                className="transition-all duration-200"
              >
                {filter.label}
              </Button>
            ))}
          </div>
        </section>

        <section className="space-y-6">
          {filteredItems.map((item, index) => (
            <Card
              key={item.id}
              className={`overflow-hidden hover:shadow-lg transition-all duration-300 fade-in fade-in-delay-${Math.min(index + 1, 3)}`}
            >
              <div className="flex">
                <div className="flex-1">
                  <CardHeader className="pb-3">
                    <div className="flex items-center justify-between mb-2">
                      <div className="flex items-center gap-2">
                        <span className="text-lg">{getTypeIcon(item.type)}</span>
                        <Badge variant={getPriorityColor(item.priority)} className="text-xs">
                          {item.type.charAt(0).toUpperCase() + item.type.slice(1)}
                        </Badge>
                        {item.priority === "high" && (
                          <Badge variant="destructive" className="text-xs">
                            Important
                          </Badge>
                        )}
                      </div>
                      <span className="text-xs text-muted-foreground">{item.date}</span>
                    </div>
                    <CardTitle className="text-xl leading-tight">{item.title}</CardTitle>
                    <div className="flex items-center gap-2 mt-2">
                      <Avatar className="h-6 w-6">
                        <AvatarImage src={`/abstract-geometric-shapes.png?height=24&width=24&query=${item.author}`} />
                        <AvatarFallback className="text-xs">
                          {item.author
                            .split(" ")
                            .map((n) => n[0])
                            .join("")}
                        </AvatarFallback>
                      </Avatar>
                      <span className="text-sm text-muted-foreground">{item.author}</span>
                    </div>
                  </CardHeader>
                  <CardContent className="pt-0">
                    <p className="text-foreground/90 mb-4">{item.content}</p>

                    {/* Engagement metrics */}
                    <div className="flex items-center gap-4 text-sm text-muted-foreground mb-4">
                      <button className="flex items-center gap-1 hover:text-primary transition-colors">
                        <span>👍</span>
                        <span>{item.engagement.likes}</span>
                      </button>
                      <button className="flex items-center gap-1 hover:text-primary transition-colors">
                        <span>🔄</span>
                        <span>{item.engagement.shares}</span>
                      </button>
                      <button className="flex items-center gap-1 hover:text-primary transition-colors">
                        <span>💬</span>
                        <span>{item.engagement.comments}</span>
                      </button>
                    </div>

                    <div className="flex gap-2">
                      <Button size="sm" variant="outline" className="transition-colors bg-transparent">
                        Read More
                      </Button>
                      {item.type === "event" && (
                        <Button size="sm" className="transition-colors">
                          View Event
                        </Button>
                      )}
                      {item.type === "advisory" && (
                        <Button size="sm" variant="secondary" className="transition-colors">
                          View Advisory
                        </Button>
                      )}
                    </div>
                  </CardContent>
                </div>

                {/* Image */}
                <div className="w-32 sm:w-48 flex-shrink-0">
                  <img src={item.image || "/placeholder.svg"} alt={item.title} className="w-full h-full object-cover" />
                </div>
              </div>
            </Card>
          ))}
        </section>

        {filteredItems.length === 0 && (
          <div className="text-center py-12 fade-in">
            <p className="text-muted-foreground">No updates found matching your criteria.</p>
          </div>
        )}
      </main>
      <SiteFooter />
    </div>
  )
}
