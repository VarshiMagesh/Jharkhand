import { SiteHeader } from "@/components/site-header"
import { SiteFooter } from "@/components/site-footer"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from "@/components/ui/accordion"
import { Users, MapPin, Camera, Compass } from "lucide-react"

export default function AboutPage() {
  return (
    <div className="min-h-screen flex flex-col bg-background text-foreground font-sans">
      <SiteHeader />
      <main id="main" className="flex-1 mx-auto max-w-6xl px-4 sm:px-6 py-10">
        {/* Hero Section with Problem Statement Visuals */}
        <section className="mb-12 relative overflow-hidden rounded-2xl bg-gradient-to-br from-primary/5 via-accent/5 to-secondary/5 p-8 md:p-12">
          <div className="absolute inset-0 opacity-10">
            <div className="h-full w-full bg-[radial-gradient(circle_at_20%_20%,_rgba(255,215,0,0.3)_0%,_transparent_50%),radial-gradient(circle_at_80%_80%,_rgba(139,69,19,0.3)_0%,_transparent_50%)]" />
          </div>

          <div className="relative z-10 grid md:grid-cols-2 gap-8 items-center">
            <div>
              <h1 className="text-3xl font-semibold text-primary text-balance mb-4">Bridging the Discovery Gap</h1>
              <p className="text-foreground/90 leading-relaxed mb-6">
                Most travelers miss Jharkhand's incredible destinations because they simply don't know they exist. We're
                changing that by connecting curious explorers with India's best-kept secrets through digital navigation,
                cultural immersion, and authentic local experiences.
              </p>

              <div className="grid grid-cols-2 gap-4 mb-6">
                <div className="text-center p-4 bg-background/50 rounded-lg">
                  <div className="text-2xl font-bold text-primary">200+</div>
                  <div className="text-sm text-muted-foreground">Hidden Destinations</div>
                </div>
                <div className="text-center p-4 bg-background/50 rounded-lg">
                  <div className="text-2xl font-bold text-primary">15+</div>
                  <div className="text-sm text-muted-foreground">Tribal Communities</div>
                </div>
              </div>
            </div>

            <div className="relative">
              <img
                src="/jharkhand-tourists-exploring-cultural-heritage-digital-navigation.jpg"
                alt="Tourists exploring Jharkhand's cultural heritage with digital navigation"
                className="w-full h-64 object-cover rounded-lg shadow-lg"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-primary/20 to-transparent rounded-lg" />
              <div className="absolute bottom-4 left-4 bg-background/90 backdrop-blur-sm rounded-lg px-3 py-2">
                <p className="text-sm font-medium text-primary">Digital Cultural Discovery</p>
                <p className="text-xs text-muted-foreground">Modern tools, ancient wisdom</p>
              </div>
            </div>
          </div>
        </section>

        {/* Problem Statement Statistics */}
        <section aria-labelledby="problem-stats" className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-4 mb-10">
          <h2 id="problem-stats" className="sr-only">
            Tourism Challenge Statistics
          </h2>

          <Card className="text-center">
            <CardHeader className="pb-2">
              <div className="mx-auto w-12 h-12 bg-primary/10 rounded-full flex items-center justify-center mb-2">
                <Users className="w-6 h-6 text-primary" />
              </div>
              <CardTitle className="text-2xl text-primary">85%</CardTitle>
              <CardDescription>Travelers unaware of Jharkhand destinations</CardDescription>
            </CardHeader>
          </Card>

          <Card className="text-center">
            <CardHeader className="pb-2">
              <div className="mx-auto w-12 h-12 bg-accent/10 rounded-full flex items-center justify-center mb-2">
                <MapPin className="w-6 h-6 text-accent" />
              </div>
              <CardTitle className="text-2xl text-accent">50+</CardTitle>
              <CardDescription>Pristine waterfalls yet to be discovered</CardDescription>
            </CardHeader>
          </Card>

          <Card className="text-center">
            <CardHeader className="pb-2">
              <div className="mx-auto w-12 h-12 bg-secondary/10 rounded-full flex items-center justify-center mb-2">
                <Camera className="w-6 h-6 text-secondary" />
              </div>
              <CardTitle className="text-2xl text-secondary">300%</CardTitle>
              <CardDescription>Increase in digital discovery tools</CardDescription>
            </CardHeader>
          </Card>

          <Card className="text-center">
            <CardHeader className="pb-2">
              <div className="mx-auto w-12 h-12 bg-muted/30 rounded-full flex items-center justify-center mb-2">
                <Compass className="w-6 h-6 text-muted-foreground" />
              </div>
              <CardTitle className="text-2xl text-muted-foreground">24/7</CardTitle>
              <CardDescription>Digital navigation support</CardDescription>
            </CardHeader>
          </Card>
        </section>

        {/* Our Solution */}
        <section className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-10" aria-labelledby="our-solution">
          <h2 id="our-solution" className="sr-only">
            Our Solution to Tourism Challenges
          </h2>

          <Card>
            <CardHeader>
              <CardTitle className="text-primary">Digital Discovery Platform</CardTitle>
              <CardDescription>Making the invisible visible through technology</CardDescription>
            </CardHeader>
            <CardContent>
              <ul className="list-disc pl-5 space-y-2 text-foreground/90">
                <li>Interactive maps revealing hidden gems and secret trails</li>
                <li>Cultural immersion guides connecting travelers with tribal communities</li>
                <li>Real-time navigation to off-the-beaten-path destinations</li>
                <li>Verified local guides sharing authentic stories and traditions</li>
              </ul>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle className="text-primary">Cultural Preservation Initiative</CardTitle>
              <CardDescription>Protecting heritage while promoting sustainable tourism</CardDescription>
            </CardHeader>
            <CardContent>
              <ul className="list-disc pl-5 space-y-2 text-foreground/90">
                <li>Community-based tourism supporting local livelihoods</li>
                <li>Digital documentation of tribal art, music, and traditions</li>
                <li>Eco-friendly travel routes minimizing environmental impact</li>
                <li>Educational programs bridging modern travelers and ancient wisdom</li>
              </ul>
              <div className="mt-4 flex gap-2">
                <Button size="sm" className="bg-primary hover:bg-primary/90">
                  Learn More
                </Button>
                <Button
                  size="sm"
                  variant="outline"
                  className="border-primary text-primary hover:bg-primary hover:text-primary-foreground bg-transparent"
                >
                  Join Initiative
                </Button>
              </div>
            </CardContent>
          </Card>
        </section>

        {/* Visual Impact Section */}
        <section className="mb-10">
          <div className="grid md:grid-cols-3 gap-6">
            <div className="relative group overflow-hidden rounded-lg">
              <img
                src="/jharkhand-tribal-cultural-motifs-digital-interface.jpg"
                alt="Tribal cultural motifs integrated with digital interface"
                className="w-full h-48 object-cover transition-transform group-hover:scale-105"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-primary/60 to-transparent" />
              <div className="absolute bottom-4 left-4 text-white">
                <h3 className="font-semibold">Cultural Integration</h3>
                <p className="text-sm opacity-90">Traditional meets digital</p>
              </div>
            </div>

            <div className="relative group overflow-hidden rounded-lg">
              <img
                src="/jharkhand-tourists-using-digital-navigation-forest.jpg"
                alt="Tourists using digital navigation tools in Jharkhand forest"
                className="w-full h-48 object-cover transition-transform group-hover:scale-105"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-accent/60 to-transparent" />
              <div className="absolute bottom-4 left-4 text-white">
                <h3 className="font-semibold">Smart Navigation</h3>
                <p className="text-sm opacity-90">Technology-guided exploration</p>
              </div>
            </div>

            <div className="relative group overflow-hidden rounded-lg">
              <img
                src="/jharkhand-community-tourism-local-guides-travelers.jpg"
                alt="Community tourism with local guides and travelers in Jharkhand"
                className="w-full h-48 object-cover transition-transform group-hover:scale-105"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-secondary/60 to-transparent" />
              <div className="absolute bottom-4 left-4 text-white">
                <h3 className="font-semibold">Community Connection</h3>
                <p className="text-sm opacity-90">Authentic local experiences</p>
              </div>
            </div>
          </div>
        </section>

        <section aria-labelledby="stats" className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-4 mb-10">
          <h2 id="stats" className="sr-only">
            Key statistics
          </h2>
          <Card>
            <CardHeader className="pb-2">
              <CardDescription>Destinations Listed</CardDescription>
              <CardTitle className="text-2xl">120+</CardTitle>
            </CardHeader>
            <CardContent className="pt-0">
              <Badge variant="secondary">Updated monthly</Badge>
            </CardContent>
          </Card>
          <Card>
            <CardHeader className="pb-2">
              <CardDescription>Protected Areas</CardDescription>
              <CardTitle className="text-2xl">11</CardTitle>
            </CardHeader>
            <CardContent className="pt-0">
              <p className="text-sm text-foreground/70">Parks & sanctuaries</p>
            </CardContent>
          </Card>
          <Card>
            <CardHeader className="pb-2">
              <CardDescription>Cultural Events</CardDescription>
              <CardTitle className="text-2xl">50+</CardTitle>
            </CardHeader>
            <CardContent className="pt-0">
              <p className="text-sm text-foreground/70">Annual calendar</p>
            </CardContent>
          </Card>
          <Card>
            <CardHeader className="pb-2">
              <CardDescription>Helpline Hours</CardDescription>
              <CardTitle className="text-2xl">9–18</CardTitle>
            </CardHeader>
            <CardContent className="pt-0">
              <Badge>Mon–Sat</Badge>
            </CardContent>
          </Card>
        </section>

        <section className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-10" aria-labelledby="initiatives-policies">
          <h2 id="initiatives-policies" className="sr-only">
            Initiatives and Policies
          </h2>
          <Card>
            <CardHeader>
              <CardTitle>Key Initiatives</CardTitle>
              <CardDescription>Building a sustainable tourism ecosystem</CardDescription>
            </CardHeader>
            <CardContent>
              <ul className="list-disc pl-5 space-y-2 text-foreground/90">
                <li>Eco-tourism circuits with community participation</li>
                <li>Heritage conservation and interpretation centers</li>
                <li>Digital booking and verified guide programs</li>
                <li>Safety standards and accessibility improvements</li>
              </ul>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>Tourism Policy Highlights</CardTitle>
              <CardDescription>Focus on inclusivity, sustainability, and growth</CardDescription>
            </CardHeader>
            <CardContent>
              <ul className="list-disc pl-5 space-y-2 text-foreground/90">
                <li>Incentives for eco-friendly homestays and operators</li>
                <li>Skill development for local youth and guides</li>
                <li>Conservation-first approach to development</li>
                <li>Data-driven planning and visitor feedback loops</li>
              </ul>
              <div className="mt-4 flex gap-2">
                <Button size="sm">Read Policy</Button>
                <Button size="sm" variant="outline">
                  Download PDF
                </Button>
              </div>
            </CardContent>
          </Card>
        </section>

        <section className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-10" aria-labelledby="org-contacts">
          <h2 id="org-contacts" className="sr-only">
            Organization and Contacts
          </h2>

          <Card>
            <CardHeader>
              <CardTitle className="text-primary">Department of Tourism</CardTitle>
              <CardDescription>Government of Jharkhand</CardDescription>
            </CardHeader>
            <CardContent className="text-foreground/90">
              <p>Office Hours: 9:00 AM – 6:00 PM (Mon–Sat)</p>
              <p>Email: tourism@jharkhand.gov.in</p>
              <p>Helpline: 1800-123-TOUR</p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle className="text-primary">Digital Innovation Hub</CardTitle>
              <CardDescription>Technology & cultural preservation</CardDescription>
            </CardHeader>
            <CardContent className="text-foreground/90">
              <p>Leading digital transformation in tourism discovery and cultural documentation.</p>
              <Button
                size="sm"
                variant="outline"
                className="mt-3 border-primary text-primary hover:bg-primary hover:text-primary-foreground bg-transparent"
              >
                Explore Tech
              </Button>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle className="text-primary">Visitor Support</CardTitle>
              <CardDescription>24/7 assistance for travelers</CardDescription>
            </CardHeader>
            <CardContent className="text-foreground/90">
              <p>Trip planning, cultural guidance, and real-time navigation support.</p>
              <Button size="sm" className="mt-3 bg-primary hover:bg-primary/90">
                Get Support
              </Button>
            </CardContent>
          </Card>
        </section>

        <section aria-labelledby="faqs">
          <h2 id="faqs" className="text-xl font-semibold mb-4 text-primary">
            Frequently Asked Questions
          </h2>
          <Accordion type="single" collapsible className="w-full">
            <AccordionItem value="item-1">
              <AccordionTrigger>How does digital navigation help discover hidden destinations?</AccordionTrigger>
              <AccordionContent>
                Our platform uses GPS mapping, local knowledge, and cultural insights to guide travelers to destinations
                that aren't found in traditional guidebooks. Interactive maps reveal secret trails, hidden waterfalls,
                and authentic cultural sites.
              </AccordionContent>
            </AccordionItem>
            <AccordionItem value="item-2">
              <AccordionTrigger>How do you ensure authentic cultural experiences?</AccordionTrigger>
              <AccordionContent>
                We work directly with tribal communities and local guides who share their authentic stories, traditions,
                and knowledge. All cultural experiences are community-approved and designed to benefit local people
                while preserving their heritage.
              </AccordionContent>
            </AccordionItem>
            <AccordionItem value="item-3">
              <AccordionTrigger>What makes Jharkhand different from other tourist destinations?</AccordionTrigger>
              <AccordionContent>
                Jharkhand offers untouched wilderness, living tribal cultures, and destinations that most travelers
                never discover. Unlike crowded tourist spots, here you'll find authentic experiences, pristine nature,
                and genuine connections with local communities.
              </AccordionContent>
            </AccordionItem>
          </Accordion>
        </section>
      </main>
      <SiteFooter />
    </div>
  )
}
