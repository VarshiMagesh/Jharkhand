"use client"

import { SiteHeader } from "@/components/site-header"
import { SiteFooter } from "@/components/site-footer"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { ShoppingBag, Star, MapPin, Truck, Heart, Award } from "lucide-react"
import { useState } from "react"

const handicrafts = [
  {
    id: 1,
    name: "Sohrai Tribal Wall Art",
    artisan: "Kumari Devi",
    village: "Hazaribagh",
    price: "₹2,500",
    originalPrice: "₹3,000",
    category: "Traditional Art",
    rating: 4.9,
    reviews: 47,
    description:
      "Authentic Sohrai art painted on canvas using traditional natural pigments and techniques passed down through generations.",
    image: "/sohrai-tribal-wall-art.jpg",
    features: ["Handmade", "Natural pigments", "Traditional technique", "Certificate of authenticity"],
    inStock: true,
    shippingTime: "5-7 days",
  },
  {
    id: 2,
    name: "Dokra Metal Craft Elephant",
    artisan: "Raman Singh",
    village: "Khunti",
    price: "₹1,800",
    originalPrice: "₹2,200",
    category: "Metal Craft",
    rating: 4.7,
    reviews: 32,
    description:
      "Beautiful Dokra metal craft elephant made using the ancient lost-wax casting technique by skilled tribal artisans.",
    image: "/dokra-metal-craft-elephant.jpg",
    features: ["Lost-wax technique", "Brass alloy", "Antique finish", "Unique design"],
    inStock: true,
    shippingTime: "3-5 days",
  },
  {
    id: 3,
    name: "Bamboo Basket Set",
    artisan: "Santoshi Devi",
    village: "Gumla",
    price: "₹850",
    originalPrice: "₹1,000",
    category: "Bamboo Craft",
    rating: 4.8,
    reviews: 28,
    description:
      "Set of 3 handwoven bamboo baskets perfect for storage and home decoration, made from locally sourced bamboo.",
    image: "/bamboo-basket-set.jpg",
    features: ["Set of 3", "Eco-friendly", "Durable", "Multi-purpose"],
    inStock: true,
    shippingTime: "4-6 days",
  },
]

const localProduce = [
  {
    id: 1,
    name: "Organic Jharkhand Honey",
    producer: "Tribal Cooperative",
    location: "Saranda Forest",
    price: "₹450",
    originalPrice: "₹500",
    category: "Honey & Bee Products",
    rating: 4.9,
    reviews: 156,
    description:
      "Pure, raw honey harvested from the pristine Saranda forests by tribal beekeepers using traditional methods.",
    image: "/organic-jharkhand-honey.jpg",
    features: ["100% Pure", "Raw & Unprocessed", "Forest sourced", "No additives"],
    inStock: true,
    weight: "500g",
    shippingTime: "2-3 days",
  },
  {
    id: 2,
    name: "Tribal Herbal Tea Blend",
    producer: "Jharkhand Herbals",
    location: "Netarhat Hills",
    price: "₹320",
    originalPrice: "₹380",
    category: "Herbal Products",
    rating: 4.6,
    reviews: 89,
    description:
      "Aromatic herbal tea blend made from wild herbs collected from Netarhat hills, known for its medicinal properties.",
    image: "/tribal-herbal-tea-blend.jpg",
    features: ["Wild herbs", "Medicinal properties", "Caffeine-free", "Traditional recipe"],
    inStock: true,
    weight: "100g",
    shippingTime: "3-4 days",
  },
  {
    id: 3,
    name: "Red Rice from Jharkhand",
    producer: "Organic Farmers Collective",
    location: "Ranchi District",
    price: "₹180",
    originalPrice: "₹220",
    category: "Grains & Cereals",
    rating: 4.7,
    reviews: 203,
    description: "Nutritious red rice grown organically by local farmers, rich in antioxidants and fiber.",
    image: "/red-rice-jharkhand.jpg",
    features: ["Organic certified", "High nutrition", "Traditional variety", "Pesticide-free"],
    inStock: true,
    weight: "1kg",
    shippingTime: "2-4 days",
  },
]

const textiles = [
  {
    id: 1,
    name: "Tussar Silk Saree",
    artisan: "Weaver Collective",
    village: "Bhagalpur",
    price: "₹4,500",
    originalPrice: "₹5,200",
    category: "Silk Textiles",
    rating: 4.8,
    reviews: 67,
    description:
      "Elegant Tussar silk saree with traditional motifs, handwoven by skilled artisans using age-old techniques.",
    image: "/tussar-silk-saree.jpg",
    features: ["Pure Tussar silk", "Handwoven", "Traditional motifs", "Natural dyes"],
    inStock: true,
    shippingTime: "7-10 days",
  },
  {
    id: 2,
    name: "Tribal Print Cotton Dupatta",
    artisan: "Madhuri Devi",
    village: "Dumka",
    price: "₹650",
    originalPrice: "₹800",
    category: "Cotton Textiles",
    rating: 4.6,
    reviews: 41,
    description:
      "Beautiful cotton dupatta with authentic tribal prints, perfect for traditional and contemporary outfits.",
    image: "/tribal-print-cotton-dupatta.jpg",
    features: ["Pure cotton", "Tribal prints", "Natural dyes", "Versatile styling"],
    inStock: true,
    shippingTime: "4-6 days",
  },
]

export default function LocalMarketplacePage() {
  const [selectedItem, setSelectedItem] = useState<any>(null)
  const [quantity, setQuantity] = useState(1)

  const handlePurchase = (item: any) => {
    setSelectedItem(item)
  }

  return (
    <div className="min-h-screen flex flex-col bg-background text-foreground font-sans">
      <SiteHeader />
      <main id="main" className="flex-1 mx-auto max-w-6xl px-4 sm:px-6 py-10">
        <header className="mb-8 fade-in">
          <h1 className="text-3xl font-semibold text-primary text-balance">Local Marketplace</h1>
          <p className="mt-2 text-foreground/90 max-w-2xl">
            Discover authentic Jharkhand products - from traditional handicrafts to organic produce, directly from local
            artisans and farmers.
          </p>
          <div className="flex items-center gap-4 mt-4 text-sm text-muted-foreground">
            <div className="flex items-center gap-1">
              <Award className="w-4 h-4 text-accent" />
              <span>Authentic products</span>
            </div>
            <div className="flex items-center gap-1">
              <Heart className="w-4 h-4 text-accent" />
              <span>Support local artisans</span>
            </div>
            <div className="flex items-center gap-1">
              <Truck className="w-4 h-4 text-accent" />
              <span>Direct from source</span>
            </div>
          </div>
        </header>

        <Tabs defaultValue="handicrafts" className="fade-in fade-in-delay-1">
          <TabsList className="grid w-full grid-cols-3">
            <TabsTrigger value="handicrafts">Handicrafts</TabsTrigger>
            <TabsTrigger value="produce">Local Produce</TabsTrigger>
            <TabsTrigger value="textiles">Textiles</TabsTrigger>
          </TabsList>

          <TabsContent value="handicrafts" className="mt-6">
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {handicrafts.map((item) => (
                <Card key={item.id} className="overflow-hidden hover:shadow-lg transition-all duration-300">
                  <div className="aspect-square overflow-hidden relative">
                    <img
                      src={item.image || "/placeholder.svg?height=300&width=300&query=jharkhand handicraft"}
                      alt={item.name}
                      className="w-full h-full object-cover"
                    />
                    {item.originalPrice !== item.price && (
                      <Badge className="absolute top-2 right-2 bg-red-500 text-white">
                        {Math.round(
                          ((Number.parseInt(item.originalPrice.slice(1)) - Number.parseInt(item.price.slice(1))) /
                            Number.parseInt(item.originalPrice.slice(1))) *
                            100,
                        )}
                        % OFF
                      </Badge>
                    )}
                  </div>
                  <CardHeader className="pb-3">
                    <div className="flex items-center justify-between">
                      <Badge variant="secondary">{item.category}</Badge>
                      <div className="flex items-center gap-1">
                        <Star className="w-4 h-4 fill-yellow-400 text-yellow-400" />
                        <span className="text-sm font-medium">{item.rating}</span>
                        <span className="text-xs text-muted-foreground">({item.reviews})</span>
                      </div>
                    </div>
                    <CardTitle className="text-lg">{item.name}</CardTitle>
                    <CardDescription className="flex items-center gap-1">
                      <span>by {item.artisan}</span>
                      <span className="text-muted-foreground">•</span>
                      <MapPin className="w-3 h-3" />
                      <span>{item.village}</span>
                    </CardDescription>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <p className="text-sm text-muted-foreground">{item.description}</p>

                    <div className="flex flex-wrap gap-1">
                      {item.features.map((feature, idx) => (
                        <Badge key={idx} variant="outline" className="text-xs">
                          {feature}
                        </Badge>
                      ))}
                    </div>

                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-2">
                        <span className="text-lg font-semibold text-primary">{item.price}</span>
                        {item.originalPrice !== item.price && (
                          <span className="text-sm text-muted-foreground line-through">{item.originalPrice}</span>
                        )}
                      </div>
                      <div className="text-xs text-muted-foreground flex items-center gap-1">
                        <Truck className="w-3 h-3" />
                        {item.shippingTime}
                      </div>
                    </div>

                    <Dialog>
                      <DialogTrigger asChild>
                        <Button onClick={() => handlePurchase(item)} className="w-full" disabled={!item.inStock}>
                          <ShoppingBag className="w-4 h-4 mr-2" />
                          {item.inStock ? "Add to Cart" : "Out of Stock"}
                        </Button>
                      </DialogTrigger>
                      <DialogContent className="max-w-md">
                        <DialogHeader>
                          <DialogTitle>Purchase {item.name}</DialogTitle>
                          <DialogDescription>Complete your order details</DialogDescription>
                        </DialogHeader>
                        <div className="space-y-4">
                          <div className="flex items-center gap-3 p-3 bg-accent/5 rounded-lg">
                            <img
                              src={item.image || "/placeholder.svg"}
                              alt={item.name}
                              className="w-16 h-16 object-cover rounded"
                            />
                            <div className="flex-1">
                              <div className="font-medium">{item.name}</div>
                              <div className="text-sm text-muted-foreground">by {item.artisan}</div>
                              <div className="text-sm font-semibold text-primary">{item.price}</div>
                            </div>
                          </div>

                          <div>
                            <Label htmlFor="quantity">Quantity</Label>
                            <Input
                              id="quantity"
                              type="number"
                              min="1"
                              max="5"
                              value={quantity}
                              onChange={(e) => setQuantity(Number.parseInt(e.target.value))}
                            />
                          </div>

                          <div>
                            <Label htmlFor="address">Delivery Address</Label>
                            <Textarea id="address" placeholder="Enter your complete address..." />
                          </div>

                          <div>
                            <Label htmlFor="notes">Special Instructions</Label>
                            <Textarea id="notes" placeholder="Any special requests or gift message..." />
                          </div>

                          <div className="flex items-center justify-between p-3 bg-primary/5 rounded-lg">
                            <span className="font-medium">Total Amount:</span>
                            <span className="text-lg font-semibold text-primary">
                              ₹{Number.parseInt(item.price.slice(1)) * quantity}
                            </span>
                          </div>

                          <Button className="w-full">
                            Place Order - ₹{Number.parseInt(item.price.slice(1)) * quantity}
                          </Button>
                        </div>
                      </DialogContent>
                    </Dialog>
                  </CardContent>
                </Card>
              ))}
            </div>
          </TabsContent>

          <TabsContent value="produce" className="mt-6">
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {localProduce.map((item) => (
                <Card key={item.id} className="overflow-hidden hover:shadow-lg transition-all duration-300">
                  <div className="aspect-square overflow-hidden relative">
                    <img
                      src={item.image || "/placeholder.svg?height=300&width=300&query=jharkhand organic produce"}
                      alt={item.name}
                      className="w-full h-full object-cover"
                    />
                    {item.originalPrice !== item.price && (
                      <Badge className="absolute top-2 right-2 bg-green-500 text-white">Fresh</Badge>
                    )}
                  </div>
                  <CardHeader className="pb-3">
                    <div className="flex items-center justify-between">
                      <Badge variant="secondary">{item.category}</Badge>
                      <div className="flex items-center gap-1">
                        <Star className="w-4 h-4 fill-yellow-400 text-yellow-400" />
                        <span className="text-sm font-medium">{item.rating}</span>
                        <span className="text-xs text-muted-foreground">({item.reviews})</span>
                      </div>
                    </div>
                    <CardTitle className="text-lg">{item.name}</CardTitle>
                    <CardDescription className="flex items-center gap-1">
                      <span>by {item.producer}</span>
                      <span className="text-muted-foreground">•</span>
                      <MapPin className="w-3 h-3" />
                      <span>{item.location}</span>
                    </CardDescription>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <p className="text-sm text-muted-foreground">{item.description}</p>

                    <div className="flex flex-wrap gap-1">
                      {item.features.map((feature, idx) => (
                        <Badge key={idx} variant="outline" className="text-xs">
                          {feature}
                        </Badge>
                      ))}
                    </div>

                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-2">
                        <span className="text-lg font-semibold text-primary">{item.price}</span>
                        <span className="text-xs text-muted-foreground">({item.weight})</span>
                        {item.originalPrice !== item.price && (
                          <span className="text-sm text-muted-foreground line-through">{item.originalPrice}</span>
                        )}
                      </div>
                      <div className="text-xs text-muted-foreground flex items-center gap-1">
                        <Truck className="w-3 h-3" />
                        {item.shippingTime}
                      </div>
                    </div>

                    <Dialog>
                      <DialogTrigger asChild>
                        <Button onClick={() => handlePurchase(item)} className="w-full" disabled={!item.inStock}>
                          <ShoppingBag className="w-4 h-4 mr-2" />
                          {item.inStock ? "Add to Cart" : "Out of Stock"}
                        </Button>
                      </DialogTrigger>
                      <DialogContent className="max-w-md">
                        <DialogHeader>
                          <DialogTitle>Purchase {item.name}</DialogTitle>
                          <DialogDescription>Complete your order details</DialogDescription>
                        </DialogHeader>
                        <div className="space-y-4">
                          <div className="flex items-center gap-3 p-3 bg-accent/5 rounded-lg">
                            <img
                              src={item.image || "/placeholder.svg"}
                              alt={item.name}
                              className="w-16 h-16 object-cover rounded"
                            />
                            <div className="flex-1">
                              <div className="font-medium">{item.name}</div>
                              <div className="text-sm text-muted-foreground">by {item.producer}</div>
                              <div className="text-sm font-semibold text-primary">
                                {item.price} ({item.weight})
                              </div>
                            </div>
                          </div>

                          <div>
                            <Label htmlFor="quantity">Quantity</Label>
                            <Input
                              id="quantity"
                              type="number"
                              min="1"
                              max="10"
                              value={quantity}
                              onChange={(e) => setQuantity(Number.parseInt(e.target.value))}
                            />
                          </div>

                          <div>
                            <Label htmlFor="address">Delivery Address</Label>
                            <Textarea id="address" placeholder="Enter your complete address..." />
                          </div>

                          <div className="flex items-center justify-between p-3 bg-primary/5 rounded-lg">
                            <span className="font-medium">Total Amount:</span>
                            <span className="text-lg font-semibold text-primary">
                              ₹{Number.parseInt(item.price.slice(1)) * quantity}
                            </span>
                          </div>

                          <Button className="w-full">
                            Place Order - ₹{Number.parseInt(item.price.slice(1)) * quantity}
                          </Button>
                        </div>
                      </DialogContent>
                    </Dialog>
                  </CardContent>
                </Card>
              ))}
            </div>
          </TabsContent>

          <TabsContent value="textiles" className="mt-6">
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {textiles.map((item) => (
                <Card key={item.id} className="overflow-hidden hover:shadow-lg transition-all duration-300">
                  <div className="aspect-square overflow-hidden relative">
                    <img
                      src={item.image || "/placeholder.svg?height=300&width=300&query=jharkhand textile"}
                      alt={item.name}
                      className="w-full h-full object-cover"
                    />
                    {item.originalPrice !== item.price && (
                      <Badge className="absolute top-2 right-2 bg-red-500 text-white">
                        {Math.round(
                          ((Number.parseInt(item.originalPrice.slice(1)) - Number.parseInt(item.price.slice(1))) /
                            Number.parseInt(item.originalPrice.slice(1))) *
                            100,
                        )}
                        % OFF
                      </Badge>
                    )}
                  </div>
                  <CardHeader className="pb-3">
                    <div className="flex items-center justify-between">
                      <Badge variant="secondary">{item.category}</Badge>
                      <div className="flex items-center gap-1">
                        <Star className="w-4 h-4 fill-yellow-400 text-yellow-400" />
                        <span className="text-sm font-medium">{item.rating}</span>
                        <span className="text-xs text-muted-foreground">({item.reviews})</span>
                      </div>
                    </div>
                    <CardTitle className="text-lg">{item.name}</CardTitle>
                    <CardDescription className="flex items-center gap-1">
                      <span>by {item.artisan}</span>
                      <span className="text-muted-foreground">•</span>
                      <MapPin className="w-3 h-3" />
                      <span>{item.village}</span>
                    </CardDescription>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <p className="text-sm text-muted-foreground">{item.description}</p>

                    <div className="flex flex-wrap gap-1">
                      {item.features.map((feature, idx) => (
                        <Badge key={idx} variant="outline" className="text-xs">
                          {feature}
                        </Badge>
                      ))}
                    </div>

                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-2">
                        <span className="text-lg font-semibold text-primary">{item.price}</span>
                        {item.originalPrice !== item.price && (
                          <span className="text-sm text-muted-foreground line-through">{item.originalPrice}</span>
                        )}
                      </div>
                      <div className="text-xs text-muted-foreground flex items-center gap-1">
                        <Truck className="w-3 h-3" />
                        {item.shippingTime}
                      </div>
                    </div>

                    <Dialog>
                      <DialogTrigger asChild>
                        <Button onClick={() => handlePurchase(item)} className="w-full" disabled={!item.inStock}>
                          <ShoppingBag className="w-4 h-4 mr-2" />
                          {item.inStock ? "Add to Cart" : "Out of Stock"}
                        </Button>
                      </DialogTrigger>
                      <DialogContent className="max-w-md">
                        <DialogHeader>
                          <DialogTitle>Purchase {item.name}</DialogTitle>
                          <DialogDescription>Complete your order details</DialogDescription>
                        </DialogHeader>
                        <div className="space-y-4">
                          <div className="flex items-center gap-3 p-3 bg-accent/5 rounded-lg">
                            <img
                              src={item.image || "/placeholder.svg"}
                              alt={item.name}
                              className="w-16 h-16 object-cover rounded"
                            />
                            <div className="flex-1">
                              <div className="font-medium">{item.name}</div>
                              <div className="text-sm text-muted-foreground">by {item.artisan}</div>
                              <div className="text-sm font-semibold text-primary">{item.price}</div>
                            </div>
                          </div>

                          <div>
                            <Label htmlFor="quantity">Quantity</Label>
                            <Input
                              id="quantity"
                              type="number"
                              min="1"
                              max="3"
                              value={quantity}
                              onChange={(e) => setQuantity(Number.parseInt(e.target.value))}
                            />
                          </div>

                          <div>
                            <Label htmlFor="address">Delivery Address</Label>
                            <Textarea id="address" placeholder="Enter your complete address..." />
                          </div>

                          <div>
                            <Label htmlFor="notes">Special Instructions</Label>
                            <Textarea id="notes" placeholder="Any special requests or gift message..." />
                          </div>

                          <div className="flex items-center justify-between p-3 bg-primary/5 rounded-lg">
                            <span className="font-medium">Total Amount:</span>
                            <span className="text-lg font-semibold text-primary">
                              ₹{Number.parseInt(item.price.slice(1)) * quantity}
                            </span>
                          </div>

                          <Button className="w-full">
                            Place Order - ₹{Number.parseInt(item.price.slice(1)) * quantity}
                          </Button>
                        </div>
                      </DialogContent>
                    </Dialog>
                  </CardContent>
                </Card>
              ))}
            </div>
          </TabsContent>
        </Tabs>
      </main>
      <SiteFooter />
    </div>
  )
}
