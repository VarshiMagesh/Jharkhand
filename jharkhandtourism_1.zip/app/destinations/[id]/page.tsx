"use client"

import { SiteHeader } from "@/components/site-header"
import { SiteFooter } from "@/components/site-footer"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { MapPin, Clock, Camera, Star, Phone, Calendar } from "lucide-react"
import { useState, useEffect } from "react"
import { useParams } from "next/navigation"
import Link from "next/link"

const destinations = [
  {
    id: 1,
    name: "Dassam Falls",
    location: "Taimara, Ranchi",
    category: "Waterfall",
    image: "/dassam-falls-jharkhand-waterfall.png",
    description: "Spectacular 144-foot waterfall cascading over granite rocks.",
    highlights: ["Photography", "Monsoon views", "Picnic spots"],
    fullDescription:
      "Dassam Falls, also known as Dassam Ghagh, is one of the most spectacular waterfalls in Jharkhand. Located about 40 km from Ranchi, this 144-foot waterfall is formed by the Kanchi River as it cascades over granite rocks. The falls are particularly magnificent during the monsoon season when the water volume is at its peak.",
    history:
      "The name 'Dassam' comes from the local word meaning 'ten streams' as the waterfall appears to split into multiple streams as it falls. Local tribal communities consider this place sacred and have been visiting for centuries.",
    timings: "6:00 AM - 6:00 PM (All days)",
    bestTime: "July to October (Monsoon season)",
    entryFee: "₹10 per person",
    facilities: ["Parking", "Food stalls", "Restrooms", "Photography spots"],
    activities: ["Photography", "Picnicking", "Nature walks", "Rock climbing"],
    nearbyAttractions: ["Hundru Falls (25 km)", "Jonha Falls (30 km)", "Ranchi Lake (40 km)"],
    coordinates: { lat: 23.4504, lng: 85.4426 },
    panoramicImage: "/dassam-falls-360-panoramic-view.jpg",
    gallery: [
      "/dassam-falls-monsoon-view.jpg",
      "/dassam-falls-winter-view.jpg",
      "/dassam-falls-sunset-view.jpg",
      "/dassam-falls-aerial-view.jpg",
    ],
  },
  {
    id: 2,
    name: "Betla National Park",
    location: "Latehar District",
    category: "Wildlife",
    image: "/betla-national-park-jharkhand-wildlife.png",
    description: "Home to tigers, elephants, and diverse flora in Palamau Tiger Reserve.",
    highlights: ["Safari tours", "Wildlife photography", "Forest lodges"],
    fullDescription:
      "Betla National Park is the first national park in Jharkhand, established in 1986. Part of the Palamau Tiger Reserve, it spans 979 square kilometers and is home to tigers, elephants, leopards, wild boar, sambhar, and over 174 bird species.",
    history:
      "Originally a hunting ground for the Chero kings, the area was declared a wildlife sanctuary in 1973 and later upgraded to a national park. The park plays a crucial role in Project Tiger conservation efforts.",
    timings: "6:00 AM - 5:00 PM (Closed on Wednesdays)",
    bestTime: "November to April",
    entryFee: "₹50 per person, Safari: ₹1500 per vehicle",
    facilities: ["Safari vehicles", "Forest lodges", "Interpretation center", "Canteen"],
    activities: ["Jungle safari", "Bird watching", "Nature photography", "Trekking"],
    nearbyAttractions: ["Palamu Fort (15 km)", "Netarhat (60 km)", "Kechki (20 km)"],
    coordinates: { lat: 23.8833, lng: 84.1833 },
    panoramicImage: "/betla-national-park-360-forest-view.jpg",
    gallery: [
      "/betla-tiger-sighting.jpg",
      "/betla-elephant-herd.jpg",
      "/betla-bird-watching.jpg",
      "/betla-forest-lodge.jpg",
    ],
  },
  // Add more destinations with similar detailed structure...
]

export default function DestinationDetailPage() {
  const params = useParams()
  const [destination, setDestination] = useState<any>(null)
  const [currentImageIndex, setCurrentImageIndex] = useState(0)
  const [showPanorama, setShowPanorama] = useState(false)

  useEffect(() => {
    const id = Number.parseInt(params.id as string)
    const found = destinations.find((d) => d.id === id)
    setDestination(found)
  }, [params.id])

  if (!destination) {
    return (
      <div className="min-h-screen flex flex-col bg-background text-foreground font-sans">
        <SiteHeader />
        <main className="flex-1 flex items-center justify-center">
          <div className="text-center">
            <h1 className="text-2xl font-semibold text-primary mb-4">Destination Not Found</h1>
            <Link href="/destinations">
              <Button>Back to Destinations</Button>
            </Link>
          </div>
        </main>
        <SiteFooter />
      </div>
    )
  }

  return (
    <div className="min-h-screen flex flex-col bg-background text-foreground font-sans">
      <SiteHeader />
      <main id="main" className="flex-1">
        {/* Hero Section with Image Gallery */}
        <section className="relative h-[60vh] overflow-hidden">
          <div className="absolute inset-0">
            <img
              src={destination.gallery?.[currentImageIndex] || destination.image}
              alt={destination.name}
              className="w-full h-full object-cover"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-transparent to-transparent" />
          </div>

          {/* Image Navigation */}
          <div className="absolute bottom-4 left-1/2 transform -translate-x-1/2 flex gap-2">
            {destination.gallery?.map((_, index) => (
              <button
                key={index}
                onClick={() => setCurrentImageIndex(index)}
                className={`w-3 h-3 rounded-full transition-all ${
                  currentImageIndex === index ? "bg-white" : "bg-white/50"
                }`}
              />
            ))}
          </div>

          {/* 360° Panoramic View Button */}
          <button
            onClick={() => setShowPanorama(true)}
            className="absolute top-4 right-4 bg-accent hover:bg-accent/90 text-accent-foreground px-4 py-2 rounded-lg flex items-center gap-2 transition-colors"
          >
            <Camera className="w-4 h-4" />
            360° View
          </button>

          {/* Destination Info Overlay */}
          <div className="absolute bottom-8 left-8 text-white">
            <div className="flex items-center gap-2 mb-2">
              <Badge className="bg-accent text-accent-foreground">{destination.category}</Badge>
              <div className="flex items-center gap-1 text-sm">
                <MapPin className="w-4 h-4" />
                {destination.location}
              </div>
            </div>
            <h1 className="text-4xl font-bold mb-2">{destination.name}</h1>
            <p className="text-lg text-white/90 max-w-2xl">{destination.description}</p>
          </div>
        </section>

        {/* 360° Panoramic Modal */}
        {showPanorama && (
          <div className="fixed inset-0 z-50 bg-black/90 flex items-center justify-center">
            <div className="relative w-full h-full max-w-6xl max-h-[80vh] bg-background rounded-lg overflow-hidden">
              <button
                onClick={() => setShowPanorama(false)}
                className="absolute top-4 right-4 z-10 bg-background/80 hover:bg-background text-foreground p-2 rounded-full"
              >
                ✕
              </button>
              <img
                src={destination.panoramicImage || "/placeholder.svg"}
                alt={`360° view of ${destination.name}`}
                className="w-full h-full object-cover"
              />
              <div className="absolute bottom-4 left-4 bg-background/90 backdrop-blur-sm rounded-lg p-3">
                <p className="text-sm font-medium">360° Panoramic View</p>
                <p className="text-xs text-muted-foreground">Drag to explore the full view</p>
              </div>
            </div>
          </div>
        )}

        {/* Content Tabs */}
        <section className="container mx-auto px-4 py-12">
          <Tabs defaultValue="overview" className="w-full">
            <TabsList className="grid w-full grid-cols-4 mb-8">
              <TabsTrigger value="overview">Overview</TabsTrigger>
              <TabsTrigger value="details">Visit Details</TabsTrigger>
              <TabsTrigger value="activities">Activities</TabsTrigger>
              <TabsTrigger value="location">Location</TabsTrigger>
            </TabsList>

            <TabsContent value="overview" className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Star className="w-5 h-5 text-accent" />
                    About {destination.name}
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <p className="text-foreground/90 leading-relaxed">{destination.fullDescription}</p>

                  <div className="grid md:grid-cols-2 gap-6">
                    <div>
                      <h3 className="font-semibold text-primary mb-3">Highlights</h3>
                      <div className="flex flex-wrap gap-2">
                        {destination.highlights.map((highlight, index) => (
                          <Badge key={index} variant="outline">
                            {highlight}
                          </Badge>
                        ))}
                      </div>
                    </div>

                    <div>
                      <h3 className="font-semibold text-primary mb-3">Historical Significance</h3>
                      <p className="text-sm text-foreground/80 leading-relaxed">{destination.history}</p>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </TabsContent>

            <TabsContent value="details" className="space-y-6">
              <div className="grid md:grid-cols-2 gap-6">
                <Card>
                  <CardHeader>
                    <CardTitle className="flex items-center gap-2">
                      <Clock className="w-5 h-5 text-accent" />
                      Visiting Information
                    </CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div>
                      <h4 className="font-medium text-primary">Timings</h4>
                      <p className="text-sm text-foreground/80">{destination.timings}</p>
                    </div>
                    <div>
                      <h4 className="font-medium text-primary">Best Time to Visit</h4>
                      <p className="text-sm text-foreground/80">{destination.bestTime}</p>
                    </div>
                    <div>
                      <h4 className="font-medium text-primary">Entry Fee</h4>
                      <p className="text-sm text-foreground/80">{destination.entryFee}</p>
                    </div>
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader>
                    <CardTitle>Facilities Available</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="grid grid-cols-2 gap-2">
                      {destination.facilities.map((facility, index) => (
                        <div key={index} className="flex items-center gap-2 text-sm">
                          <div className="w-2 h-2 bg-accent rounded-full" />
                          {facility}
                        </div>
                      ))}
                    </div>
                  </CardContent>
                </Card>
              </div>
            </TabsContent>

            <TabsContent value="activities" className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle>Things to Do</CardTitle>
                  <CardDescription>Popular activities and experiences at {destination.name}</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="grid md:grid-cols-2 gap-4">
                    {destination.activities.map((activity, index) => (
                      <div
                        key={index}
                        className="flex items-center gap-3 p-3 border rounded-lg hover:bg-accent/5 transition-colors"
                      >
                        <div className="w-8 h-8 bg-accent/10 rounded-full flex items-center justify-center">
                          <Star className="w-4 h-4 text-accent" />
                        </div>
                        <span className="font-medium">{activity}</span>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle>Nearby Attractions</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-2">
                    {destination.nearbyAttractions.map((attraction, index) => (
                      <div key={index} className="flex items-center gap-2 text-sm">
                        <MapPin className="w-4 h-4 text-accent" />
                        {attraction}
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            </TabsContent>

            <TabsContent value="location" className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <MapPin className="w-5 h-5 text-accent" />
                    Location & Map
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  {/* Mini-map of Jharkhand highlighting the location */}
                  <div className="relative bg-accent/5 rounded-lg p-6 border">
                    <div className="text-center">
                      <div className="inline-block bg-accent/10 rounded-lg p-4 mb-4">
                        <MapPin className="w-8 h-8 text-accent mx-auto" />
                      </div>
                      <h3 className="font-semibold text-primary mb-2">{destination.name}</h3>
                      <p className="text-sm text-foreground/80 mb-4">{destination.location}</p>
                      <div className="flex justify-center gap-4 text-xs text-foreground/60">
                        <span>Lat: {destination.coordinates.lat}</span>
                        <span>Lng: {destination.coordinates.lng}</span>
                      </div>
                    </div>
                  </div>

                  <div className="flex gap-4">
                    <Button className="flex-1">
                      <Phone className="w-4 h-4 mr-2" />
                      Get Directions
                    </Button>
                    <Button variant="outline" className="flex-1 bg-transparent">
                      <Calendar className="w-4 h-4 mr-2" />
                      Plan Visit
                    </Button>
                  </div>
                </CardContent>
              </Card>
            </TabsContent>
          </Tabs>
        </section>
      </main>
      <SiteFooter />
    </div>
  )
}
