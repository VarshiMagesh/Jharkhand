"use client"

import { SiteHeader } from "@/components/site-header"
import { SiteFooter } from "@/components/site-footer"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { useEffect, useState } from "react"
import Link from "next/link"

const destinations = [
  {
    id: 1,
    name: "Dassam Falls",
    location: "Taimara, Ranchi",
    category: "Waterfall",
    image: "/dassam-falls-jharkhand-waterfall.png",
    description: "Spectacular 144-foot waterfall cascading over granite rocks.",
    highlights: ["Photography", "Monsoon views", "Picnic spots"],
  },
  {
    id: 2,
    name: "Betla National Park",
    location: "Latehar District",
    category: "Wildlife",
    image: "/betla-national-park-jharkhand-wildlife.png",
    description: "Home to tigers, elephants, and diverse flora in Palamau Tiger Reserve.",
    highlights: ["Safari tours", "Wildlife photography", "Forest lodges"],
  },
  {
    id: 3,
    name: "Netarhat",
    location: "Latehar District",
    category: "Hill Station",
    image: "/netarhat-sunset-jharkhand.png",
    description: "Queen of Chotanagpur with breathtaking sunrise and sunset views.",
    highlights: ["Sunrise point", "Cool climate", "Pine forests"],
  },
  {
    id: 4,
    name: "Hundru Falls",
    location: "Ranchi",
    category: "Waterfall",
    image: "/hundru-falls-jharkhand-waterfall.jpg",
    description: "320-foot waterfall formed by Subarnarekha River.",
    highlights: ["Trekking", "Rock climbing", "Natural pools"],
  },
  {
    id: 5,
    name: "Jagannath Temple",
    location: "Ranchi",
    category: "Heritage",
    image: "/jagannath-temple-ranchi-heritage.jpg",
    description: "Replica of famous Puri temple with annual Rath Yatra.",
    highlights: ["Religious significance", "Architecture", "Festivals"],
  },
  {
    id: 6,
    name: "Deoghar",
    location: "Deoghar District",
    category: "Pilgrimage",
    image: "/deoghar-baidyanath-temple-jharkhand.jpg",
    description: "Sacred Jyotirlinga temple attracting millions of devotees.",
    highlights: ["Baidyanath Temple", "Kanwar Yatra", "Spiritual retreat"],
  },
  {
    id: 7,
    name: "Parasnath Hills",
    location: "Giridih District",
    category: "Trekking",
    image: "/parasnath-hills-jharkhand-trekking.jpg",
    description: "Highest peak in Jharkhand, sacred to Jains.",
    highlights: ["Trekking trails", "Jain temples", "Panoramic views"],
  },
  {
    id: 8,
    name: "Hazaribagh Wildlife Sanctuary",
    location: "Hazaribagh District",
    category: "Wildlife",
    image: "/hazaribagh-wildlife-sanctuary-jharkhand.jpg",
    description: "Rich biodiversity with leopards, sambars, and migratory birds.",
    highlights: ["Bird watching", "Nature walks", "Cantt area"],
  },
]

export default function DestinationsPage() {
  const [searchTerm, setSearchTerm] = useState("")
  const [selectedCategory, setSelectedCategory] = useState("All")
  const [isVisible, setIsVisible] = useState(false)

  const categories = ["All", "Waterfall", "Wildlife", "Hill Station", "Heritage", "Pilgrimage", "Trekking"]

  const filteredDestinations = destinations.filter((dest) => {
    const matchesSearch =
      dest.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      dest.location.toLowerCase().includes(searchTerm.toLowerCase())
    const matchesCategory = selectedCategory === "All" || dest.category === selectedCategory
    return matchesSearch && matchesCategory
  })

  useEffect(() => {
    const timer = setTimeout(() => setIsVisible(true), 100)
    return () => clearTimeout(timer)
  }, [])

  return (
    <div className="min-h-screen flex flex-col bg-background text-foreground font-sans">
      <SiteHeader />
      <main id="main" className="flex-1 mx-auto max-w-6xl px-4 sm:px-6 py-10">
        <header className="mb-8 fade-in">
          <h1 className="text-3xl font-semibold text-primary text-balance">Explore Destinations</h1>
          <p className="mt-2 text-foreground/90">Discover the natural beauty and cultural heritage of Jharkhand.</p>
        </header>

        <section className="mb-8 fade-in fade-in-delay-1">
          <div className="flex flex-col sm:flex-row gap-4 mb-6">
            <Input
              placeholder="Search destinations..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="flex-1"
            />
          </div>
          <div className="flex flex-wrap gap-2">
            {categories.map((category) => (
              <Button
                key={category}
                variant={selectedCategory === category ? "default" : "outline"}
                size="sm"
                onClick={() => setSelectedCategory(category)}
                className="transition-all duration-200"
              >
                {category}
              </Button>
            ))}
          </div>
        </section>

        <section className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {filteredDestinations.map((destination, index) => (
            <Card
              key={destination.id}
              className={`overflow-hidden hover:shadow-lg transition-all duration-300 hover:-translate-y-1 ${
                isVisible ? `card-dealer card-dealer-${(index % 6) + 1}` : "opacity-0"
              }`}
            >
              <div className="aspect-video overflow-hidden">
                <img
                  src={destination.image || "/placeholder.svg"}
                  alt={destination.name}
                  className="w-full h-full object-cover transition-transform duration-300 hover:scale-105"
                />
              </div>
              <CardHeader className="pb-2">
                <div className="flex items-center justify-between">
                  <Badge variant="secondary" className="text-xs">
                    {destination.category}
                  </Badge>
                  <span className="text-xs text-muted-foreground">{destination.location}</span>
                </div>
                <CardTitle className="text-xl">{destination.name}</CardTitle>
                <CardDescription>{destination.description}</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="flex flex-wrap gap-1 mb-4">
                  {destination.highlights.map((highlight, idx) => (
                    <Badge key={idx} variant="outline" className="text-xs">
                      {highlight}
                    </Badge>
                  ))}
                </div>
                <Link href={`/destinations/${destination.id}`}>
                  <Button className="w-full transition-colors">Learn More</Button>
                </Link>
              </CardContent>
            </Card>
          ))}
        </section>

        {filteredDestinations.length === 0 && (
          <div className="text-center py-12 fade-in">
            <p className="text-muted-foreground">No destinations found matching your criteria.</p>
          </div>
        )}
      </main>
      <SiteFooter />
    </div>
  )
}
