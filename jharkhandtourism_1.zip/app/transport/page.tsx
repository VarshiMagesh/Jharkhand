"use client"

import Link from "next/link"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Input } from "@/components/ui/input"
import { Badge } from "@/components/ui/badge"

export default function TransportPage() {
  return (
    <main className="container mx-auto px-4 py-8">
      <header className="mb-8">
        <h1 className="text-3xl font-semibold text-pretty">Transport</h1>
        <p className="text-muted-foreground max-w-2xl mt-2">
          Official transport and tour packages operated by authorized partners.
        </p>
      </header>

      <section className="mb-6 grid grid-cols-1 md:grid-cols-4 gap-4">
        <Input placeholder="Search routes or operator" aria-label="Search transport" />
        <Select>
          <SelectTrigger aria-label="Select type">
            <SelectValue placeholder="Type" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="car">Car</SelectItem>
            <SelectItem value="bus">Bus</SelectItem>
            <SelectItem value="van">Van</SelectItem>
            <SelectItem value="tour">Tour package</SelectItem>
          </SelectContent>
        </Select>
        <Select>
          <SelectTrigger aria-label="Select duration">
            <SelectValue placeholder="Duration" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="half">Half Day</SelectItem>
            <SelectItem value="full">Full Day</SelectItem>
            <SelectItem value="multi">Multi Day</SelectItem>
          </SelectContent>
        </Select>
        <Select>
          <SelectTrigger aria-label="Select pickup">
            <SelectValue placeholder="Pickup" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="ranchi">Ranchi</SelectItem>
            <SelectItem value="betla">Betla</SelectItem>
            <SelectItem value="netarhat">Netarhat</SelectItem>
            <SelectItem value="deoghar">Deoghar</SelectItem>
          </SelectContent>
        </Select>
      </section>

      <section aria-labelledby="offers" className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <h2 id="offers" className="sr-only">
          Official transport offers
        </h2>

        {[
          {
            title: "Ranchi → Dassam Falls round trip",
            tag: "Car • Full Day",
            desc: "AC sedan with licensed driver, fuel included.",
          },
          {
            title: "Betla Safari shuttle",
            tag: "Van • Half Day",
            desc: "Park entry assistance, shared van to safari gate.",
          },
          {
            title: "Netarhat weekend package",
            tag: "Tour package • 2N/3D",
            desc: "Transport + hotel + guided sightseeing.",
          },
        ].map((item) => (
          <Card key={item.title}>
            <CardHeader>
              <div className="flex items-center justify-between">
                <CardTitle className="text-lg">{item.title}</CardTitle>
                <Badge variant="secondary">{item.tag}</Badge>
              </div>
              <CardDescription>{item.desc}</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="flex gap-3">
                <Button asChild>
                  <Link href="#">Book now</Link>
                </Button>
                <Button variant="outline" asChild>
                  <Link href="#">Learn more →</Link>
                </Button>
              </div>
            </CardContent>
          </Card>
        ))}
      </section>
    </main>
  )
}
