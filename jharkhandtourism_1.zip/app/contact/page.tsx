import { SiteHeader } from "@/components/site-header"
import { SiteFooter } from "@/components/site-footer"
import { ContactSection } from "@/components/home/contact"

export default function ContactPage() {
  return (
    <div className="min-h-screen flex flex-col bg-background text-foreground font-sans">
      <SiteHeader />
      <main id="main" className="flex-1">
        <ContactSection />
      </main>
      <SiteFooter />
    </div>
  )
}
