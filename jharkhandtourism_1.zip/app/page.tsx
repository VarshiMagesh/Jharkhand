"use client"

import { useState } from "react"
import { SiteHeader } from "@/components/site-header"
import { SiteFooter } from "@/components/site-footer"
import PreHomepageAnimation from "@/components/pre-homepage-animation"

// Unique home-only components (previews and curated content)
import HomeHero from "@/components/home/home-hero"
import HomeHighlights from "@/components/home/home-highlights"
import FeaturedDestinations from "@/components/home/featured-destinations"
import Festivals from "@/components/home/festivals"
import Testimonials from "@/components/home/testimonials"
import TravelCTA from "@/components/home/travel-cta"

export default function HomePage() {
  const [showAnimation, setShowAnimation] = useState(true)

  const handleAnimationComplete = () => {
    setShowAnimation(false)
  }

  return (
    <>
      {showAnimation && <PreHomepageAnimation onComplete={handleAnimationComplete} />}

      <div className="min-h-screen flex flex-col bg-background text-foreground font-sans">
        <SiteHeader />
        <main id="main" className="flex-1">
          <HomeHero />

          <section aria-labelledby="highlights" className="container mx-auto px-4 py-10">
            <h2 id="highlights" className="text-xl font-semibold text-foreground text-balance">
              Highlights
            </h2>
            <div className="mt-4">
              <HomeHighlights />
            </div>
          </section>

          <section aria-labelledby="featured" className="container mx-auto px-4 py-10">
            <div className="flex items-center justify-between">
              <h2 id="featured" className="text-xl font-semibold text-foreground text-balance">
                Featured Destinations
              </h2>
              <a href="/destinations" className="text-sm underline">
                See all
              </a>
            </div>
            <div className="mt-4">
              <FeaturedDestinations />
            </div>
          </section>

          <section aria-labelledby="festivals" className="container mx-auto px-4 py-10">
            <h2 id="festivals" className="text-xl font-semibold text-foreground text-balance">
              Festivals & Culture
            </h2>
            <div className="mt-4">
              <Festivals />
            </div>
          </section>

          <section aria-labelledby="testimonials" className="container mx-auto px-4 py-10">
            <h2 id="testimonials" className="text-xl font-semibold text-foreground text-balance">
              Traveler Stories
            </h2>
            <div className="mt-4">
              <Testimonials />
            </div>
          </section>

          <section aria-labelledby="plan" className="container mx-auto px-4 py-12">
            <h2 id="plan" className="sr-only">
              Plan your trip
            </h2>
            <TravelCTA />
          </section>
        </main>
        <SiteFooter />
      </div>
    </>
  )
}
