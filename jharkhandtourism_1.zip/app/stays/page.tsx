"use client"

import Image from "next/image"
import Link from "next/link"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"

export default function StaysPage() {
  return (
    <main className="container mx-auto px-4 py-8">
      <header className="mb-8">
        <h1 className="text-3xl font-semibold text-pretty">Book Stays</h1>
        <p className="text-muted-foreground max-w-2xl mt-2">
          Government-verified hotels, eco-stays, and homestays across Jharkhand. Safe, vetted, and officially listed.
        </p>
      </header>

      <section aria-labelledby="filters" className="mb-6">
        <h2 id="filters" className="sr-only">
          Filters
        </h2>
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
          <Input placeholder="Search by name or location" aria-label="Search stays" />
          <Select>
            <SelectTrigger aria-label="Select region">
              <SelectValue placeholder="Region" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="ranchi">Ranchi</SelectItem>
              <SelectItem value="netarhat">Netarhat</SelectItem>
              <SelectItem value="betla">Betla</SelectItem>
              <SelectItem value="deoghar">Deoghar</SelectItem>
            </SelectContent>
          </Select>
          <Select>
            <SelectTrigger aria-label="Select type">
              <SelectValue placeholder="Stay type" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="hotel">Hotel</SelectItem>
              <SelectItem value="eco">Eco-stay</SelectItem>
              <SelectItem value="homestay">Homestay</SelectItem>
            </SelectContent>
          </Select>
          <Select>
            <SelectTrigger aria-label="Select price range">
              <SelectValue placeholder="Price range" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="budget">Budget</SelectItem>
              <SelectItem value="mid">Mid-range</SelectItem>
              <SelectItem value="premium">Premium</SelectItem>
            </SelectContent>
          </Select>
        </div>
      </section>

      <section aria-labelledby="results" className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <h2 id="results" className="sr-only">
          Verified stays
        </h2>

        {[
          {
            title: "Betla Eco Lodge",
            location: "Betla National Park",
            tag: "Eco-stay",
            img: "/betla-eco-lodge-forest-cottage.png",
            desc: "Eco-friendly cottages near park gates. Guided safaris available.",
          },
          {
            title: "Netarhat View Hotel",
            location: "Netarhat",
            tag: "Hotel",
            img: "/netarhat-sunset-hotel-facade.png",
            desc: "Comfortable rooms overlooking the “Queen of Chotanagpur” hills.",
          },
          {
            title: "Dassam Riverside Homestay",
            location: "Dassam Falls, Ranchi",
            tag: "Homestay",
            img: "/dassam-falls-riverside-homestay.png",
            desc: "Local hospitality with easy access to the waterfalls and trails.",
          },
        ].map((stay) => (
          <Card key={stay.title} className="overflow-hidden">
            <CardHeader className="p-0">
              <Image
                src={stay.img || "/placeholder.svg"}
                alt={stay.title}
                width={400}
                height={240}
                className="w-full h-48 object-cover"
              />
            </CardHeader>
            <CardContent className="p-4">
              <div className="flex items-center justify-between">
                <CardTitle className="text-lg">{stay.title}</CardTitle>
                <Badge variant="secondary">{stay.tag}</Badge>
              </div>
              <CardDescription className="mt-1">{stay.location}</CardDescription>
              <p className="mt-3 text-sm text-muted-foreground">{stay.desc}</p>
              <div className="mt-4 flex gap-3">
                <Button asChild>
                  <Link href="#">View details</Link>
                </Button>
                <Button variant="outline" asChild>
                  <Link href="#">Learn more →</Link>
                </Button>
              </div>
            </CardContent>
          </Card>
        ))}
      </section>
    </main>
  )
}
