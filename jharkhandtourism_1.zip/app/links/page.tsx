import { SiteHeader } from "@/components/site-header"
import { SiteFooter } from "@/components/site-footer"
import { ResourcesSection } from "@/components/home/resources"

export default function LinksPage() {
  return (
    <div className="min-h-screen flex flex-col bg-background text-foreground font-sans">
      <SiteHeader />
      <main id="main" className="flex-1">
        <ResourcesSection />
      </main>
      <SiteFooter />
    </div>
  )
}
