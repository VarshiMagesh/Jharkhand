"use client"

import { SiteHeader } from "@/components/site-header"
import { SiteFooter } from "@/components/site-footer"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Calendar } from "@/components/ui/calendar"
import { useState } from "react"

const stays = [
  {
    id: 1,
    name: "Betla Forest Lodge",
    location: "Betla National Park",
    type: "Eco Lodge",
    price: "₹2,500/night",
    rating: 4.5,
    amenities: ["WiFi", "Restaurant", "Safari booking", "Nature walks"],
    image: "/betla-eco-lodge-forest-cottage.png",
    description: "Comfortable eco-friendly accommodation within the national park premises.",
  },
  {
    id: 2,
    name: "Netarhat Hill Resort",
    location: "Netarhat",
    type: "Hill Resort",
    price: "₹3,200/night",
    rating: 4.3,
    amenities: ["Mountain view", "Bonfire", "Trekking guide", "Local cuisine"],
    image: "/netarhat-hill-resort-jharkhand.jpg",
    description: "Scenic hilltop resort with panoramic valley views and sunrise point access.",
  },
]

const guides = [
  {
    id: 1,
    name: "Ravi Kumar",
    specialization: "Wildlife & Nature",
    experience: "8 years",
    languages: ["Hindi", "English", "Santhali"],
    rate: "₹1,500/day",
    rating: 4.8,
    certifications: ["Jharkhand Tourism Certified", "Wildlife Guide License"],
    description: "Expert in Betla National Park wildlife tracking and bird watching.",
  },
  {
    id: 2,
    name: "Sunita Devi",
    specialization: "Cultural Heritage",
    experience: "6 years",
    languages: ["Hindi", "English", "Mundari"],
    rate: "₹1,200/day",
    rating: 4.6,
    certifications: ["Heritage Guide Certified", "First Aid Trained"],
    description: "Specialist in tribal culture, handicrafts, and traditional festivals.",
  },
]

const transport = [
  {
    id: 1,
    name: "Ranchi to Betla Safari Package",
    type: "Tour Package",
    duration: "2 Days / 1 Night",
    price: "₹8,500/person",
    includes: ["AC Transport", "Accommodation", "Safari", "Meals", "Guide"],
    vehicle: "Tempo Traveller (12 seater)",
    description: "Complete wildlife experience with comfortable transport and expert guidance.",
  },
  {
    id: 2,
    name: "Netarhat Sunrise Tour",
    type: "Day Trip",
    duration: "1 Day",
    price: "₹2,800/person",
    includes: ["AC Car", "Driver", "Fuel", "Parking"],
    vehicle: "Sedan/SUV (4 seater)",
    description: "Early morning departure to catch the spectacular Netarhat sunrise.",
  },
]

export default function MarketplacePage() {
  const [selectedDate, setSelectedDate] = useState<Date | undefined>(new Date())
  const [bookingType, setBookingType] = useState("")
  const [selectedItem, setSelectedItem] = useState<any>(null)

  const handleBooking = (item: any, type: string) => {
    setSelectedItem(item)
    setBookingType(type)
  }

  return (
    <div className="min-h-screen flex flex-col bg-background text-foreground font-sans">
      <SiteHeader />
      <main id="main" className="flex-1 mx-auto max-w-6xl px-4 sm:px-6 py-10">
        <header className="mb-8 fade-in">
          <h1 className="text-3xl font-semibold text-primary text-balance">Marketplace</h1>
          <p className="mt-2 text-foreground/90">
            Book verified stays, guides, and transport for your Jharkhand journey.
          </p>
        </header>

        <Tabs defaultValue="stays" className="fade-in fade-in-delay-1">
          <TabsList className="grid w-full grid-cols-3">
            <TabsTrigger value="stays">Stays</TabsTrigger>
            <TabsTrigger value="guides">Guides</TabsTrigger>
            <TabsTrigger value="transport">Transport</TabsTrigger>
          </TabsList>

          <TabsContent value="stays" className="mt-6">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              {stays.map((stay) => (
                <Card key={stay.id} className="overflow-hidden hover:shadow-lg transition-all duration-300">
                  <div className="aspect-video overflow-hidden">
                    <img
                      src={stay.image || "/placeholder.svg"}
                      alt={stay.name}
                      className="w-full h-full object-cover"
                    />
                  </div>
                  <CardHeader>
                    <div className="flex items-center justify-between">
                      <Badge variant="secondary">{stay.type}</Badge>
                      <div className="flex items-center gap-1">
                        <span className="text-sm">⭐</span>
                        <span className="text-sm font-medium">{stay.rating}</span>
                      </div>
                    </div>
                    <CardTitle>{stay.name}</CardTitle>
                    <CardDescription>{stay.location}</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <p className="text-sm text-muted-foreground mb-3">{stay.description}</p>
                    <div className="flex flex-wrap gap-1 mb-4">
                      {stay.amenities.map((amenity, idx) => (
                        <Badge key={idx} variant="outline" className="text-xs">
                          {amenity}
                        </Badge>
                      ))}
                    </div>
                    <div className="flex items-center justify-between">
                      <span className="text-lg font-semibold text-primary">{stay.price}</span>
                      <Dialog>
                        <DialogTrigger asChild>
                          <Button onClick={() => handleBooking(stay, "stay")}>Book Now</Button>
                        </DialogTrigger>
                        <DialogContent className="max-w-md">
                          <DialogHeader>
                            <DialogTitle>Book {stay.name}</DialogTitle>
                            <DialogDescription>Complete your booking details</DialogDescription>
                          </DialogHeader>
                          <div className="space-y-4">
                            <div>
                              <Label>Check-in Date</Label>
                              <Calendar
                                mode="single"
                                selected={selectedDate}
                                onSelect={setSelectedDate}
                                className="rounded-md border"
                              />
                            </div>
                            <div>
                              <Label htmlFor="guests">Number of Guests</Label>
                              <Input id="guests" type="number" min="1" max="6" defaultValue="2" />
                            </div>
                            <div>
                              <Label htmlFor="special-requests">Special Requests</Label>
                              <Textarea id="special-requests" placeholder="Any special requirements..." />
                            </div>
                            <Button className="w-full">Confirm Booking - {stay.price}</Button>
                          </div>
                        </DialogContent>
                      </Dialog>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </TabsContent>

          <TabsContent value="guides" className="mt-6">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              {guides.map((guide) => (
                <Card key={guide.id} className="hover:shadow-lg transition-all duration-300">
                  <CardHeader>
                    <div className="flex items-center justify-between">
                      <Badge variant="secondary">{guide.specialization}</Badge>
                      <div className="flex items-center gap-1">
                        <span className="text-sm">⭐</span>
                        <span className="text-sm font-medium">{guide.rating}</span>
                      </div>
                    </div>
                    <CardTitle>{guide.name}</CardTitle>
                    <CardDescription>{guide.experience} experience</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <p className="text-sm text-muted-foreground mb-3">{guide.description}</p>
                    <div className="space-y-2 mb-4">
                      <div className="flex items-center gap-2">
                        <span className="text-sm font-medium">Languages:</span>
                        <span className="text-sm">{guide.languages.join(", ")}</span>
                      </div>
                      <div className="flex flex-wrap gap-1">
                        {guide.certifications.map((cert, idx) => (
                          <Badge key={idx} variant="outline" className="text-xs">
                            {cert}
                          </Badge>
                        ))}
                      </div>
                    </div>
                    <div className="flex items-center justify-between">
                      <span className="text-lg font-semibold text-primary">{guide.rate}</span>
                      <Dialog>
                        <DialogTrigger asChild>
                          <Button onClick={() => handleBooking(guide, "guide")}>Hire Guide</Button>
                        </DialogTrigger>
                        <DialogContent className="max-w-md">
                          <DialogHeader>
                            <DialogTitle>Hire {guide.name}</DialogTitle>
                            <DialogDescription>Book your certified guide</DialogDescription>
                          </DialogHeader>
                          <div className="space-y-4">
                            <div>
                              <Label>Tour Date</Label>
                              <Calendar
                                mode="single"
                                selected={selectedDate}
                                onSelect={setSelectedDate}
                                className="rounded-md border"
                              />
                            </div>
                            <div>
                              <Label htmlFor="group-size">Group Size</Label>
                              <Input id="group-size" type="number" min="1" max="15" defaultValue="4" />
                            </div>
                            <div>
                              <Label htmlFor="tour-details">Tour Requirements</Label>
                              <Textarea id="tour-details" placeholder="Describe your tour preferences..." />
                            </div>
                            <Button className="w-full">Confirm Booking - {guide.rate}</Button>
                          </div>
                        </DialogContent>
                      </Dialog>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </TabsContent>

          <TabsContent value="transport" className="mt-6">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              {transport.map((item) => (
                <Card key={item.id} className="hover:shadow-lg transition-all duration-300">
                  <CardHeader>
                    <div className="flex items-center justify-between">
                      <Badge variant="secondary">{item.type}</Badge>
                      <span className="text-sm text-muted-foreground">{item.duration}</span>
                    </div>
                    <CardTitle>{item.name}</CardTitle>
                    <CardDescription>{item.vehicle}</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <p className="text-sm text-muted-foreground mb-3">{item.description}</p>
                    <div className="space-y-2 mb-4">
                      <div className="text-sm font-medium">Package Includes:</div>
                      <div className="flex flex-wrap gap-1">
                        {item.includes.map((include, idx) => (
                          <Badge key={idx} variant="outline" className="text-xs">
                            {include}
                          </Badge>
                        ))}
                      </div>
                    </div>
                    <div className="flex items-center justify-between">
                      <span className="text-lg font-semibold text-primary">{item.price}</span>
                      <Dialog>
                        <DialogTrigger asChild>
                          <Button onClick={() => handleBooking(item, "transport")}>Book Package</Button>
                        </DialogTrigger>
                        <DialogContent className="max-w-md">
                          <DialogHeader>
                            <DialogTitle>Book {item.name}</DialogTitle>
                            <DialogDescription>Reserve your transport package</DialogDescription>
                          </DialogHeader>
                          <div className="space-y-4">
                            <div>
                              <Label>Travel Date</Label>
                              <Calendar
                                mode="single"
                                selected={selectedDate}
                                onSelect={setSelectedDate}
                                className="rounded-md border"
                              />
                            </div>
                            <div>
                              <Label htmlFor="passengers">Number of Passengers</Label>
                              <Input id="passengers" type="number" min="1" max="12" defaultValue="4" />
                            </div>
                            <div>
                              <Label htmlFor="pickup">Pickup Location</Label>
                              <Input id="pickup" placeholder="Enter pickup address..." />
                            </div>
                            <div>
                              <Label htmlFor="notes">Additional Notes</Label>
                              <Textarea id="notes" placeholder="Any special requirements..." />
                            </div>
                            <Button className="w-full">Confirm Booking - {item.price}</Button>
                          </div>
                        </DialogContent>
                      </Dialog>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </TabsContent>
        </Tabs>
      </main>
      <SiteFooter />
    </div>
  )
}
