"use client"

import { SiteHeader } from "@/components/site-header"
import { SiteFooter } from "@/components/site-footer"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Calendar } from "@/components/ui/calendar"
import { MapPin, Clock, Users, Star } from "lucide-react"
import { useState } from "react"

const stays = [
  {
    id: 1,
    name: "Betla Forest Lodge",
    location: "Betla National Park",
    type: "Eco Lodge",
    price: "₹2,500/night",
    rating: 4.5,
    amenities: ["WiFi", "Restaurant", "Safari booking", "Nature walks"],
    image: "/betla-eco-lodge-forest-cottage.png",
    description: "Comfortable eco-friendly accommodation within the national park premises.",
  },
  {
    id: 2,
    name: "Netarhat Hill Resort",
    location: "Netarhat",
    type: "Hill Resort",
    price: "₹3,200/night",
    rating: 4.3,
    amenities: ["Mountain view", "Bonfire", "Trekking guide", "Local cuisine"],
    image: "/netarhat-hill-resort-jharkhand.jpg",
    description: "Scenic hilltop resort with panoramic valley views and sunrise point access.",
  },
  {
    id: 3,
    name: "Ranchi Heritage Hotel",
    location: "Ranchi City Center",
    type: "Heritage Hotel",
    price: "₹4,000/night",
    rating: 4.6,
    amenities: ["Heritage architecture", "Cultural programs", "City tours", "Spa"],
    image: "/ranchi-heritage-hotel.jpg",
    description: "Historic hotel showcasing Jharkhand's architectural heritage with modern amenities.",
  },
]

const itineraryPackages = [
  {
    id: 1,
    name: "Wildlife & Waterfalls Explorer",
    duration: "5 Days / 4 Nights",
    price: "₹15,500/person",
    destinations: ["Betla National Park", "Hundru Falls", "Jonha Falls", "Dassam Falls"],
    includes: ["Accommodation", "All meals", "Safari", "Transport", "Guide"],
    highlights: ["Tiger spotting", "Waterfall photography", "Tribal village visit"],
    image: "/wildlife-waterfalls-package.jpg",
  },
  {
    id: 2,
    name: "Cultural Heritage Trail",
    duration: "4 Days / 3 Nights",
    price: "₹12,800/person",
    destinations: ["Ranchi", "Deoghar", "Rajrappa", "Baidyanath Temple"],
    includes: ["Heritage hotels", "Cultural shows", "Temple visits", "Local cuisine"],
    highlights: ["Ancient temples", "Tribal art", "Traditional festivals"],
    image: "/cultural-heritage-package.jpg",
  },
  {
    id: 3,
    name: "Adventure Trekking Circuit",
    duration: "6 Days / 5 Nights",
    price: "₹18,200/person",
    destinations: ["Netarhat", "Parasnath Hill", "Dalma Hills", "Tagore Hill"],
    includes: ["Camping gear", "Trekking guide", "Meals", "First aid", "Transport"],
    highlights: ["Sunrise treks", "Hill station views", "Adventure activities"],
    image: "/adventure-trekking-package.jpg",
  },
]

const transport = [
  {
    id: 1,
    name: "Ranchi to Betla Safari Package",
    type: "Tour Package",
    duration: "2 Days / 1 Night",
    price: "₹8,500/person",
    includes: ["AC Transport", "Accommodation", "Safari", "Meals", "Guide"],
    vehicle: "Tempo Traveller (12 seater)",
    description: "Complete wildlife experience with comfortable transport and expert guidance.",
  },
  {
    id: 2,
    name: "Netarhat Sunrise Tour",
    type: "Day Trip",
    duration: "1 Day",
    price: "₹2,800/person",
    includes: ["AC Car", "Driver", "Fuel", "Parking"],
    vehicle: "Sedan/SUV (4 seater)",
    description: "Early morning departure to catch the spectacular Netarhat sunrise.",
  },
  {
    id: 3,
    name: "Jharkhand Grand Circuit",
    type: "Multi-day Package",
    duration: "7 Days / 6 Nights",
    price: "₹22,000/person",
    includes: ["Luxury coach", "All accommodations", "All meals", "Entry fees", "Professional guide"],
    vehicle: "Luxury Coach (35 seater)",
    description: "Comprehensive tour covering all major destinations across Jharkhand.",
  },
]

export default function PlanYourVisitPage() {
  const [selectedDate, setSelectedDate] = useState<Date | undefined>(new Date())
  const [bookingType, setBookingType] = useState("")
  const [selectedItem, setSelectedItem] = useState<any>(null)

  const handleBooking = (item: any, type: string) => {
    setSelectedItem(item)
    setBookingType(type)
  }

  return (
    <div className="min-h-screen flex flex-col bg-background text-foreground font-sans">
      <SiteHeader />
      <main id="main" className="flex-1 mx-auto max-w-6xl px-4 sm:px-6 py-10">
        <header className="mb-8 fade-in">
          <h1 className="text-3xl font-semibold text-primary text-balance">Plan Your Visit</h1>
          <p className="mt-2 text-foreground/90 max-w-2xl">
            Create your perfect Jharkhand adventure with curated itineraries, verified accommodations, and seamless
            travel planning.
          </p>
        </header>

        <Tabs defaultValue="itineraries" className="fade-in fade-in-delay-1">
          <TabsList className="grid w-full grid-cols-3">
            <TabsTrigger value="itineraries">Itineraries</TabsTrigger>
            <TabsTrigger value="stays">Accommodations</TabsTrigger>
            <TabsTrigger value="transport">Transport</TabsTrigger>
          </TabsList>

          <TabsContent value="itineraries" className="mt-6">
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {itineraryPackages.map((pkg) => (
                <Card key={pkg.id} className="overflow-hidden hover:shadow-lg transition-all duration-300">
                  <div className="aspect-video overflow-hidden">
                    <img
                      src={pkg.image || "/placeholder.svg?height=200&width=400&query=jharkhand travel package"}
                      alt={pkg.name}
                      className="w-full h-full object-cover"
                    />
                  </div>
                  <CardHeader>
                    <div className="flex items-center justify-between">
                      <Badge variant="secondary" className="bg-accent/10 text-accent">
                        {pkg.duration}
                      </Badge>
                      <div className="flex items-center gap-1">
                        <Clock className="w-4 h-4 text-muted-foreground" />
                        <span className="text-sm text-muted-foreground">{pkg.duration.split(" ")[0]} days</span>
                      </div>
                    </div>
                    <CardTitle className="text-lg">{pkg.name}</CardTitle>
                    <CardDescription className="flex items-center gap-1">
                      <MapPin className="w-4 h-4" />
                      {pkg.destinations.length} destinations
                    </CardDescription>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div>
                      <h4 className="text-sm font-medium text-primary mb-2">Destinations</h4>
                      <div className="flex flex-wrap gap-1">
                        {pkg.destinations.slice(0, 3).map((dest, idx) => (
                          <Badge key={idx} variant="outline" className="text-xs">
                            {dest}
                          </Badge>
                        ))}
                        {pkg.destinations.length > 3 && (
                          <Badge variant="outline" className="text-xs">
                            +{pkg.destinations.length - 3} more
                          </Badge>
                        )}
                      </div>
                    </div>

                    <div>
                      <h4 className="text-sm font-medium text-primary mb-2">Highlights</h4>
                      <ul className="text-sm text-muted-foreground space-y-1">
                        {pkg.highlights.map((highlight, idx) => (
                          <li key={idx} className="flex items-center gap-2">
                            <div className="w-1.5 h-1.5 bg-accent rounded-full" />
                            {highlight}
                          </li>
                        ))}
                      </ul>
                    </div>

                    <div className="flex items-center justify-between pt-2">
                      <span className="text-lg font-semibold text-primary">{pkg.price}</span>
                      <Dialog>
                        <DialogTrigger asChild>
                          <Button onClick={() => handleBooking(pkg, "itinerary")}>Book Package</Button>
                        </DialogTrigger>
                        <DialogContent className="max-w-md">
                          <DialogHeader>
                            <DialogTitle>Book {pkg.name}</DialogTitle>
                            <DialogDescription>Plan your {pkg.duration} adventure</DialogDescription>
                          </DialogHeader>
                          <div className="space-y-4">
                            <div>
                              <Label>Preferred Start Date</Label>
                              <Calendar
                                mode="single"
                                selected={selectedDate}
                                onSelect={setSelectedDate}
                                className="rounded-md border w-full"
                              />
                            </div>
                            <div>
                              <Label htmlFor="travelers">Number of Travelers</Label>
                              <Input id="travelers" type="number" min="1" max="8" defaultValue="2" />
                            </div>
                            <div>
                              <Label htmlFor="preferences">Special Preferences</Label>
                              <Textarea
                                id="preferences"
                                placeholder="Dietary requirements, accessibility needs, interests..."
                              />
                            </div>
                            <Button className="w-full">Confirm Booking - {pkg.price}</Button>
                          </div>
                        </DialogContent>
                      </Dialog>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </TabsContent>

          <TabsContent value="stays" className="mt-6">
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {stays.map((stay) => (
                <Card key={stay.id} className="overflow-hidden hover:shadow-lg transition-all duration-300">
                  <div className="aspect-video overflow-hidden">
                    <img
                      src={stay.image || "/placeholder.svg?height=200&width=400&query=jharkhand accommodation"}
                      alt={stay.name}
                      className="w-full h-full object-cover"
                    />
                  </div>
                  <CardHeader>
                    <div className="flex items-center justify-between">
                      <Badge variant="secondary">{stay.type}</Badge>
                      <div className="flex items-center gap-1">
                        <Star className="w-4 h-4 fill-yellow-400 text-yellow-400" />
                        <span className="text-sm font-medium">{stay.rating}</span>
                      </div>
                    </div>
                    <CardTitle>{stay.name}</CardTitle>
                    <CardDescription className="flex items-center gap-1">
                      <MapPin className="w-4 h-4" />
                      {stay.location}
                    </CardDescription>
                  </CardHeader>
                  <CardContent>
                    <p className="text-sm text-muted-foreground mb-3">{stay.description}</p>
                    <div className="flex flex-wrap gap-1 mb-4">
                      {stay.amenities.map((amenity, idx) => (
                        <Badge key={idx} variant="outline" className="text-xs">
                          {amenity}
                        </Badge>
                      ))}
                    </div>
                    <div className="flex items-center justify-between">
                      <span className="text-lg font-semibold text-primary">{stay.price}</span>
                      <Dialog>
                        <DialogTrigger asChild>
                          <Button onClick={() => handleBooking(stay, "stay")}>Book Now</Button>
                        </DialogTrigger>
                        <DialogContent className="max-w-md">
                          <DialogHeader>
                            <DialogTitle>Book {stay.name}</DialogTitle>
                            <DialogDescription>Complete your booking details</DialogDescription>
                          </DialogHeader>
                          <div className="space-y-4">
                            <div>
                              <Label>Check-in Date</Label>
                              <Calendar
                                mode="single"
                                selected={selectedDate}
                                onSelect={setSelectedDate}
                                className="rounded-md border w-full"
                              />
                            </div>
                            <div>
                              <Label htmlFor="guests">Number of Guests</Label>
                              <Input id="guests" type="number" min="1" max="6" defaultValue="2" />
                            </div>
                            <div>
                              <Label htmlFor="special-requests">Special Requests</Label>
                              <Textarea id="special-requests" placeholder="Any special requirements..." />
                            </div>
                            <Button className="w-full">Confirm Booking - {stay.price}</Button>
                          </div>
                        </DialogContent>
                      </Dialog>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </TabsContent>

          <TabsContent value="transport" className="mt-6">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              {transport.map((item) => (
                <Card key={item.id} className="hover:shadow-lg transition-all duration-300">
                  <CardHeader>
                    <div className="flex items-center justify-between">
                      <Badge variant="secondary">{item.type}</Badge>
                      <span className="text-sm text-muted-foreground flex items-center gap-1">
                        <Clock className="w-4 h-4" />
                        {item.duration}
                      </span>
                    </div>
                    <CardTitle>{item.name}</CardTitle>
                    <CardDescription className="flex items-center gap-1">
                      <Users className="w-4 h-4" />
                      {item.vehicle}
                    </CardDescription>
                  </CardHeader>
                  <CardContent>
                    <p className="text-sm text-muted-foreground mb-3">{item.description}</p>
                    <div className="space-y-2 mb-4">
                      <div className="text-sm font-medium text-primary">Package Includes:</div>
                      <div className="flex flex-wrap gap-1">
                        {item.includes.map((include, idx) => (
                          <Badge key={idx} variant="outline" className="text-xs">
                            {include}
                          </Badge>
                        ))}
                      </div>
                    </div>
                    <div className="flex items-center justify-between">
                      <span className="text-lg font-semibold text-primary">{item.price}</span>
                      <Dialog>
                        <DialogTrigger asChild>
                          <Button onClick={() => handleBooking(item, "transport")}>Book Package</Button>
                        </DialogTrigger>
                        <DialogContent className="max-w-md">
                          <DialogHeader>
                            <DialogTitle>Book {item.name}</DialogTitle>
                            <DialogDescription>Reserve your transport package</DialogDescription>
                          </DialogHeader>
                          <div className="space-y-4">
                            <div>
                              <Label>Travel Date</Label>
                              <Calendar
                                mode="single"
                                selected={selectedDate}
                                onSelect={setSelectedDate}
                                className="rounded-md border w-full"
                              />
                            </div>
                            <div>
                              <Label htmlFor="passengers">Number of Passengers</Label>
                              <Input id="passengers" type="number" min="1" max="12" defaultValue="4" />
                            </div>
                            <div>
                              <Label htmlFor="pickup">Pickup Location</Label>
                              <Input id="pickup" placeholder="Enter pickup address..." />
                            </div>
                            <div>
                              <Label htmlFor="notes">Additional Notes</Label>
                              <Textarea id="notes" placeholder="Any special requirements..." />
                            </div>
                            <Button className="w-full">Confirm Booking - {item.price}</Button>
                          </div>
                        </DialogContent>
                      </Dialog>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </TabsContent>
        </Tabs>
      </main>
      <SiteFooter />
    </div>
  )
}
