"use client"

import { SiteHeader } from "@/components/site-header"
import { SiteFooter } from "@/components/site-footer"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Label } from "@/components/ui/label"
import { Input } from "@/components/ui/input"
import { Textarea } from "@/components/ui/textarea"
import { Checkbox } from "@/components/ui/checkbox"
import { Switch } from "@/components/ui/switch"
import { Badge } from "@/components/ui/badge"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Progress } from "@/components/ui/progress"

export default function ProfilePage() {
  return (
    <div className="min-h-screen flex flex-col bg-background text-foreground font-sans">
      <SiteHeader />
      <main id="main" className="flex-1 mx-auto max-w-6xl px-4 sm:px-6 py-10">
        <header className="mb-8 fade-in">
          <div className="flex items-center gap-6">
            <Avatar className="h-20 w-20">
              <AvatarImage src="/diverse-profile-avatars.png" />
              <AvatarFallback className="text-lg">RK</AvatarFallback>
            </Avatar>
            <div>
              <h1 className="text-3xl font-semibold text-primary text-balance">Ravi Kumar</h1>
              <p className="mt-1 text-foreground/90">Explorer • Nature Enthusiast • Ranchi</p>
              <div className="flex items-center gap-2 mt-2">
                <Badge variant="secondary">Verified Traveler</Badge>
                <Badge variant="outline">5 Trips Completed</Badge>
              </div>
            </div>
          </div>
        </header>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          <div className="lg:col-span-2 space-y-6">
            <Card className="fade-in fade-in-delay-1">
              <CardHeader>
                <CardTitle>Personal Information</CardTitle>
                <CardDescription>Keep your details up to date for better recommendations</CardDescription>
              </CardHeader>
              <CardContent>
                <form className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div>
                    <Label htmlFor="fullName">Full name</Label>
                    <Input id="fullName" defaultValue="Ravi Kumar" />
                  </div>
                  <div>
                    <Label htmlFor="email">Email</Label>
                    <Input id="email" type="email" defaultValue="ravi.kumar@example.com" />
                  </div>
                  <div>
                    <Label htmlFor="phone">Phone</Label>
                    <Input id="phone" defaultValue="+91 9876 543210" />
                  </div>
                  <div>
                    <Label htmlFor="city">Home city</Label>
                    <Input id="city" defaultValue="Ranchi, Jharkhand" />
                  </div>
                  <div className="sm:col-span-2">
                    <Label htmlFor="bio">Bio</Label>
                    <Textarea
                      id="bio"
                      defaultValue="Passionate about exploring Jharkhand's natural beauty and cultural heritage. Love photography and wildlife watching."
                      className="min-h-[100px]"
                    />
                  </div>
                  <div className="sm:col-span-2">
                    <Button type="button" className="transition-colors">
                      Save changes
                    </Button>
                  </div>
                </form>
              </CardContent>
            </Card>

            <Card className="fade-in fade-in-delay-2">
              <CardHeader>
                <CardTitle>Travel Statistics</CardTitle>
                <CardDescription>Your journey through Jharkhand</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-6">
                  <div className="text-center">
                    <div className="text-2xl font-bold text-primary">5</div>
                    <div className="text-sm text-muted-foreground">Destinations Visited</div>
                  </div>
                  <div className="text-center">
                    <div className="text-2xl font-bold text-primary">12</div>
                    <div className="text-sm text-muted-foreground">Days Traveled</div>
                  </div>
                  <div className="text-center">
                    <div className="text-2xl font-bold text-primary">3</div>
                    <div className="text-sm text-muted-foreground">Guides Hired</div>
                  </div>
                  <div className="text-center">
                    <div className="text-2xl font-bold text-primary">8</div>
                    <div className="text-sm text-muted-foreground">Reviews Written</div>
                  </div>
                </div>
                <div className="space-y-3">
                  <div>
                    <div className="flex justify-between text-sm mb-1">
                      <span>Explorer Level Progress</span>
                      <span>Level 2 (75%)</span>
                    </div>
                    <Progress value={75} className="h-2" />
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card className="fade-in fade-in-delay-3">
              <CardHeader>
                <CardTitle>Recent Activity</CardTitle>
                <CardDescription>Your latest adventures</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="flex items-center gap-3 p-3 rounded-lg bg-muted/50">
                    <div className="h-2 w-2 bg-primary rounded-full"></div>
                    <div className="flex-1">
                      <p className="text-sm font-medium">Visited Dassam Falls</p>
                      <p className="text-xs text-muted-foreground">2 days ago • Rated 5 stars</p>
                    </div>
                  </div>
                  <div className="flex items-center gap-3 p-3 rounded-lg bg-muted/50">
                    <div className="h-2 w-2 bg-accent rounded-full"></div>
                    <div className="flex-1">
                      <p className="text-sm font-medium">Booked Betla Safari</p>
                      <p className="text-xs text-muted-foreground">1 week ago • Upcoming trip</p>
                    </div>
                  </div>
                  <div className="flex items-center gap-3 p-3 rounded-lg bg-muted/50">
                    <div className="h-2 w-2 bg-muted-foreground rounded-full"></div>
                    <div className="flex-1">
                      <p className="text-sm font-medium">Hired guide for Netarhat</p>
                      <p className="text-xs text-muted-foreground">2 weeks ago • Completed</p>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>

          <div className="space-y-6">
            <Card className="fade-in fade-in-delay-1">
              <CardHeader>
                <CardTitle>Travel Preferences</CardTitle>
                <CardDescription>Customize your experience</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="flex items-center gap-2">
                  <Checkbox id="pref-nature" defaultChecked />
                  <Label htmlFor="pref-nature">Nature & Waterfalls</Label>
                </div>
                <div className="flex items-center gap-2">
                  <Checkbox id="pref-wildlife" defaultChecked />
                  <Label htmlFor="pref-wildlife">Wildlife & Safaris</Label>
                </div>
                <div className="flex items-center gap-2">
                  <Checkbox id="pref-culture" />
                  <Label htmlFor="pref-culture">Culture & Heritage</Label>
                </div>
                <div className="flex items-center gap-2">
                  <Checkbox id="pref-adventure" defaultChecked />
                  <Label htmlFor="pref-adventure">Adventure & Trekking</Label>
                </div>
                <div className="flex items-center gap-2">
                  <Checkbox id="pref-pilgrimage" />
                  <Label htmlFor="pref-pilgrimage">Pilgrimage Sites</Label>
                </div>
              </CardContent>
            </Card>

            <Card className="fade-in fade-in-delay-2">
              <CardHeader>
                <CardTitle>Notifications</CardTitle>
                <CardDescription>Stay updated</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="font-medium">Travel Advisories</p>
                    <p className="text-sm text-muted-foreground">Safety alerts</p>
                  </div>
                  <Switch id="noti-advisories" defaultChecked />
                </div>
                <div className="flex items-center justify-between">
                  <div>
                    <p className="font-medium">Booking Updates</p>
                    <p className="text-sm text-muted-foreground">Confirmations</p>
                  </div>
                  <Switch id="noti-bookings" defaultChecked />
                </div>
                <div className="flex items-center justify-between">
                  <div>
                    <p className="font-medium">Events & Festivals</p>
                    <p className="text-sm text-muted-foreground">Cultural calendar</p>
                  </div>
                  <Switch id="noti-events" />
                </div>
              </CardContent>
            </Card>

            <Card className="fade-in fade-in-delay-3">
              <CardHeader>
                <CardTitle>Quick Actions</CardTitle>
                <CardDescription>Manage your account</CardDescription>
              </CardHeader>
              <CardContent className="space-y-3">
                <Button variant="outline" className="w-full justify-start bg-transparent">
                  📄 Download Travel History
                </Button>
                <Button variant="outline" className="w-full justify-start bg-transparent">
                  🎫 Manage Bookings
                </Button>
                <Button variant="outline" className="w-full justify-start bg-transparent">
                  💳 Payment Methods
                </Button>
                <Button variant="outline" className="w-full justify-start bg-transparent">
                  🔒 Privacy Settings
                </Button>
              </CardContent>
            </Card>
          </div>
        </div>
      </main>
      <SiteFooter />
    </div>
  )
}
